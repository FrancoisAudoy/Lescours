function [ W0 ] = Resoud( W, P)
%RESOUD Summary of this function goes here
%   Detailed explanation goes here
% W is a vector
% P is a point of the sample (same dim as W)

W0 =-( W' * P);


end

