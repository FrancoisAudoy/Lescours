import ij.ImagePlus;
import ij.*;
import ij.plugin.filter.*;
import ij.process.*;


public class Premier_Plugin implements PlugInFilter {

  public void run(ImageProcessor ip) {
    // TODO Auto-generated method stub
    //ip.flipHorizontal();
    for(int i=0; i<=ip.getWidth()/2; ++i){
      for(int j=0; j<=ip.getHeight(); ++j){
        int tmp= ip.getPixel(i, j);
        ip.putPixel(i, j, ip.getPixel(ip.getWidth()-i,j));
        ip.putPixel(ip.getWidth()-i,j, tmp);
      }
    }
  }

  public int setup(String arg, ImagePlus imp) {
    // TODO Auto-generated method stub
    return DOES_RGB;
  }

}
