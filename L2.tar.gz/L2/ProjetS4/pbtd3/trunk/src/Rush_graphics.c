#include <stdio.h>
#include <stdlib.h> 
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h> 
#include <assert.h>
#include <math.h>
#include "game.h"
#include "piece.h"
#include "graphics.h"
#define GRID_SIDE 6
#define TAILLE_TAB 6

int TAILLE_CASE = 70;
int TAILLE_ESPACE_ENTRE_CASE = 5;
int TAILLE_X_SCORE = 200;
int TAILLE_Y_SCORE = 120;
int TAILLE_ESPACE = 30;

struct window_s{
  int size_w;
  int size_h;
  SDL_Surface *screen;
  SDL_Event event;
};

window new_window(){	
  window w = malloc(sizeof(*w));
  assert(w != NULL);
  
  w->size_w = TAILLE_CASE*GRID_SIDE + TAILLE_ESPACE_ENTRE_CASE*(GRID_SIDE - 1) + TAILLE_ESPACE*3+ TAILLE_X_SCORE;
  w->size_h = TAILLE_CASE*GRID_SIDE + TAILLE_ESPACE_ENTRE_CASE*(GRID_SIDE - 1) + 60;

  assert(SDL_Init(SDL_INIT_VIDEO) != -1);
  assert(TTF_Init() != -1);

  w->screen = SDL_SetVideoMode(w->size_w, w->size_h, 32, SDL_HWSURFACE);
  //Mise en place de la barre caption
  SDL_WM_SetCaption("RUSH HOUR", NULL);

  return w;
}

void delete_window(window w){
  SDL_FreeSurface(w->screen);
  free(w);
}

dir move_event(window w, game g){

  while(1){
    SDL_WaitEvent(&(w->event)); 

    switch(w->event.type) 
      {
      case SDL_QUIT: 
	delete_window(w);
	delete_game(g);
	TTF_Quit();
	SDL_Quit();
	exit(EXIT_SUCCESS);
	break;

      case SDL_KEYUP:
	switch(w->event.key.keysym.sym)
	  {
	  case SDLK_UP :
	    return UP;
	    break;
	  case SDLK_DOWN :
	    return DOWN;
	    break;
	  case SDLK_RIGHT :
	    return RIGHT;
	    break;
	  case SDLK_LEFT :
	    return LEFT;
	    break;
	  default :
	    break;
	  }
	break;

      default :
	break;
      }
  }
}

static void img_display(window w, SDL_Surface* img, SDL_Rect coord, char* str){
  img = SDL_LoadBMP(str);
  SDL_BlitSurface(img, NULL, w->screen, &coord);
  SDL_FreeSurface(img);
}
void display_screen(window w, game g){
  SDL_FillRect(w->screen, NULL, SDL_MapRGB(w->screen->format, 70, 70, 70));
  SDL_Rect coord;
  SDL_Surface* img=NULL;
  coord.x = 30;
  coord.y = 30;
  char* str =(char*) malloc(sizeof(char) * 20);
  int grille_affiche [TAILLE_TAB][TAILLE_TAB];
  //initialisation de la grille
   for(int x=0; x<TAILLE_TAB; x++)
     for(int y=0; y<TAILLE_TAB; y++)
       grille_affiche[x][y]=-1;
   //recuperation de toute les pieces
    int nb_piece=game_nb_pieces(g);
    cpiece pieces[nb_piece];
    for(int add=0; add<nb_piece;++add)
      pieces[add]=game_piece(g,add);
    //placement des pieces dans la grille
    for(int i=0; i<nb_piece; i++){
      if(can_move_x(pieces[i])){
	for(int j=0; j<get_width(pieces[i]); j++){
	  grille_affiche[get_x(pieces[i])+j][get_y(pieces[i])]=i;
	}
      }   
      if(can_move_y(pieces[i])){
	for(int j=0; j<get_height(pieces[i]); j++){
	  grille_affiche[get_x(pieces[i])][get_y(pieces[i])+j]=i;
	}
      }
    }
     for(int j = GRID_SIDE-1; j >=0; j--){
       for(int i =0; i <GRID_SIDE; i++){
   
      sprintf(str, "../img/%d.bmp", (int)  grille_affiche[i][j]);
      img_display(w, img, coord, str);
      coord.x += TAILLE_CASE + TAILLE_ESPACE_ENTRE_CASE;
    }
      coord.x = 30;
      coord.y += TAILLE_CASE + TAILLE_ESPACE_ENTRE_CASE;
    }
  display_score(w, g);
  free(str);
  SDL_Flip(w->screen);
}

static void text_display(window w, SDL_Surface* texte, SDL_Color couleur, SDL_Rect coord, char* str, char* police){
  //Initialisation Police de caractère.
  TTF_Font* Police =TTF_OpenFont(police, 30);
  if (Police == NULL) {
    printf("Erreur SDL_ttf : %s\n", TTF_GetError());
    exit(1);
  }
  texte = TTF_RenderText_Blended(Police, str, couleur);
  SDL_BlitSurface(texte, NULL, w->screen, &coord);
  TTF_CloseFont(Police);
  SDL_FreeSurface(texte);
  }
void display_score(window w, game g){
  SDL_Rect coord;
  SDL_Surface* img=NULL;
  char* str = malloc(sizeof(char) * 10);
  char* police = malloc(sizeof(char) * 30);
  police = "../img/dk_butterfly.otf";
  SDL_Color couleurNoire = {0, 0, 0};

  coord.x = w->size_w - TAILLE_X_SCORE - TAILLE_ESPACE;
  coord.y = 30;
  img_display(w, img, coord, "../img/score.bmp");

  coord.x += 20;
  coord.y += 20;
  text_display(w, img, couleurNoire, coord, "Moves :",  police);

  coord.y += 40;
  sprintf(str, "%d",(int)game_nb_moves(g));
  text_display(w, img, couleurNoire, coord, str, police);

  free(str);
}

  int main( int argc, char *argv[ ] ){
    dir d;
    int x;
    int x2;
    int y;
    int y2;
    piece pieces[5];
    pieces[0] = new_piece(0, 3, 2, 1, true, false);  //1ere piece est en position de partie
    pieces[1] = new_piece(4, 2, 1, 2, false, true);
    pieces[2] = new_piece(3, 3, 1, 2, false, true);
    pieces[3] = new_piece(5, 2, 1, 3, false, true);
    pieces[4] = new_piece(1, 1, 3, 1, true, false);

    window w = new_window();
    game g = new_game(GRID_SIDE,GRID_SIDE,5,pieces);
        
    SDL_Rect voitR;
    voitR.x=TAILLE_ESPACE;
    voitR.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
    voitR.w=150;
    voitR.h=70;

    SDL_Rect voitB;
    voitB.x=TAILLE_ESPACE+TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
    voitB.y=TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4+TAILLE_ESPACE;
    voitB.w=225;
    voitB.h=70;

    SDL_Rect voitMM;
    voitMM.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3;
    voitMM.y=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_ESPACE;
    voitMM.w=70;
    voitMM.h=150;

    SDL_Rect voitV;
    voitV.x=TAILLE_CASE*4+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*4;
    voitV.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
    voitV.w=70;
    voitV.h=150;

    SDL_Rect voitBR;
    voitBR.x=TAILLE_CASE*5+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*5;
    voitBR.y=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_ESPACE;
    voitBR.w=70;
    voitBR.h=225;

    //Uint32 color= SDL_MapRGB(w->screen->format, 0x00, 0xff, 0xff);
    bool running=true;

    //Boucle(BASE DU PROGRAMME)
    for(; ;)
      {
	while(running){
          SDL_Event event;
          while(SDL_PollEvent(& event)){
	    switch(event.type){
	      
	    case SDL_QUIT: running= false; break;
	      
	    case SDL_MOUSEMOTION :
	      x= event.motion.x;
	      y= event.motion.y;

	      if(x>voitR.x && x<voitR.x+voitR.w && y>voitR.y && y<voitR.y+voitR.h){
               d= move_event(w, g);
               play_move(g, 0, d, 1);
               if (d==RIGHT) {
			voitR.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voitR.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
		} 
               if(d==LEFT) {
			voitR.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voitR.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
		}
	      }
	      

	      if(x>voitB.x && x<voitB.x+voitB.w && y>voitB.y && y<voitB.y+voitB.h){
		d= move_event(w, g);
		play_move(g, 4, d, 1);
                 if (d==RIGHT) {
			voitB.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voitB.y=TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4+TAILLE_ESPACE;
		} 
                 if(d==LEFT) {
			voitB.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voitB.y=TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4+TAILLE_ESPACE;
		  }
		}


	     if(x>voitMM.x && x<voitMM.x+voitMM.w && y>voitMM.y && y<voitMM.y+voitMM.h){
	       d= move_event(w, g);
	       play_move(g, 2, d, 1) ;
               if (d==DOWN) {
			voitMM.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3;// Si avance est à 1 alors on incrémente x
                        voitMM.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voitMM.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3; // Sinon on décrémente x 
                        voitMM.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	     

	     if(x>voitV.x && x<voitV.x+voitV.w && y>voitV.y && y<voitV.y+voitV.h){
	       d= move_event(w, g);
	       play_move(g, 1, d, 1);
               if (d==DOWN) {
			voitV.x=TAILLE_CASE*4+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*4;// Si avance est à 1 alors on incrémente x
                        voitV.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voitV.x=TAILLE_CASE*4+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*4; // Sinon on décrémente x 
                        voitV.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	     

	     if(x>voitBR.x && x<voitBR.x+voitBR.w && y>voitBR.y && y<voitBR.y+voitBR.h){
	       d= move_event(w, g);
	       play_move(g, 3, d, 1);
               if (d==DOWN) {
			voitBR.x=TAILLE_CASE*5+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*5;// Si avance est à 1 alors on incrémente x
                        voitBR.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP){
			voitBR.x=TAILLE_CASE*5+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*5; // Sinon on décrémente x 
                        voitBR.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	     
	     
	    case SDL_MOUSEBUTTONDOWN:
	      x2= event.button.x;
	      y2= event.button.y;

	      if(x2>voitR.x && x2<voitR.x+voitR.w && y2>voitR.y && y2<voitR.y+voitR.h){
               d= move_event(w, g);
               play_move(g, 0, d, 1);
               if (d==RIGHT) {
			voitR.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voitR.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
		} 
               if(d==LEFT) {
			voitR.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voitR.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
		}
	      }
	      

	      if(x2>voitB.x && x2<voitB.x+voitB.w && y2>voitB.y && y2<voitB.y+voitB.h){
		d= move_event(w, g);
		play_move(g, 4, d, 1);
                 if (d==RIGHT) {
			voitB.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voitB.y=TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4+TAILLE_ESPACE;
		} 
                 if(d==LEFT) {
			voitB.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voitB.y=TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4+TAILLE_ESPACE;
		  }
		}


	     if(x2>voitMM.x && x2<voitMM.x+voitMM.w && y2>voitMM.y && y2<voitMM.y+voitMM.h){
	       d= move_event(w, g);
	       play_move(g, 2, d, 1) ;
               if (d==DOWN) {
			voitMM.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3;// Si avance est à 1 alors on incrémente x
                        voitMM.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voitMM.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3; // Sinon on décrémente x 
                        voitMM.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	     

	     if(x2>voitV.x && x2<voitV.x+voitV.w && y2>voitV.y && y2<voitV.y+voitV.h){
	       d= move_event(w, g);
	       play_move(g, 1, d, 1);
               if (d==DOWN) {
			voitV.x=TAILLE_CASE*4+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*4;// Si avance est à 1 alors on incrémente x
                        voitV.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voitV.x=TAILLE_CASE*4+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*4; // Sinon on décrémente x 
                        voitV.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	     

	     if(x2>voitBR.x && x2<voitBR.x+voitBR.w && y2>voitBR.y && y2<voitBR.y+voitBR.h){
	       d= move_event(w, g);
	       play_move(g, 3, d, 1);
               if (d==DOWN) {
			voitBR.x=TAILLE_CASE*5+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*5;// Si avance est à 1 alors on incrémente x
                        voitBR.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP){
			voitBR.x=TAILLE_CASE*5+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*5; // Sinon on décrémente x 
                        voitBR.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		  }
		}
	    }
	  }

	  //logic && render     
          //SDL_FillRect(w->screen,&voitBR,color);// pour coloré les fontoms il faut changer &voit**
          //SDL_Flip(w->screen);
	 display_screen(w,g);
         if( game_over_hr(g) ){
         printf(" ** la partie est finie ** ");
         }
	}
      }
	  	
    //Libération des surfaces
    delete_game(g); 
    delete_window(w);
    TTF_Quit();
 
    //On quitte SDL 
    SDL_Quit(); 
      
    return 0 ;
  }

