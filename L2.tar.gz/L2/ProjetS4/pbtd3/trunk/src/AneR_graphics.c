#include <stdio.h>
#include <stdlib.h> 
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h> 
#include <assert.h>
#include <math.h>
#include "game.h"
#include "piece.h"
#include "graphics.h"
#define HAUTEUR_G 5
#define LARGEUR_G 4
#define TAILLE_TAB 10


int TAILLE_CASE = 70;
int TAILLE_ESPACE_ENTRE_CASE = 5;
int TAILLE_X_SCORE = 200;
int TAILLE_Y_SCORE = 120;
int TAILLE_ESPACE = 30;

struct window_s{
  int size_w;
  int size_h;
  SDL_Surface *screen;
  SDL_Event event;
};

window new_window(){	
  window w = malloc(sizeof(*w));
  assert(w != NULL);
  
  w->size_w = TAILLE_CASE*LARGEUR_G + TAILLE_ESPACE_ENTRE_CASE*(LARGEUR_G - 1) + TAILLE_ESPACE*3+ TAILLE_X_SCORE;
  w->size_h = TAILLE_CASE*HAUTEUR_G + TAILLE_ESPACE_ENTRE_CASE*(HAUTEUR_G - 1) + 60;

  assert(SDL_Init(SDL_INIT_VIDEO) != -1);
  assert(TTF_Init() != -1);

  w->screen = SDL_SetVideoMode(w->size_w, w->size_h, 32, SDL_HWSURFACE);
  //Mise en place de la barre caption
  SDL_WM_SetCaption("ANE ROUGE", NULL);

  return w;
}

void delete_window(window w){
  SDL_FreeSurface(w->screen);
  free(w);
}

dir move_event(window w, game g){

  while(1){
    SDL_WaitEvent(&(w->event)); 

    switch(w->event.type) 
      {
      case SDL_QUIT: 
	delete_window(w);
	delete_game(g);
	TTF_Quit();
	SDL_Quit();
	exit(EXIT_SUCCESS);
	break;

      case SDL_KEYUP:
	switch(w->event.key.keysym.sym)
	  {
	  case SDLK_UP :
	    return UP;
	    break;
	  case SDLK_DOWN :
	    return DOWN;
	    break;
	  case SDLK_RIGHT :
	    return RIGHT;
	    break;
	  case SDLK_LEFT :
	    return LEFT;
	    break;
	  default :
	    break;
	  }
	break;

      default :
	break;
      }
  }
}

static void img_display(window w, SDL_Surface* img, SDL_Rect coord, char* str){
  img = SDL_LoadBMP(str);
  SDL_BlitSurface(img, NULL, w->screen, &coord);
  SDL_FreeSurface(img);
}
void display_screen(window w, game g){
  SDL_FillRect(w->screen, NULL, SDL_MapRGB(w->screen->format, 70, 70, 70));
  SDL_Rect coord;
  SDL_Surface* img=NULL;
  coord.x = 30;
  coord.y = 30;
  char* str =(char*) malloc(sizeof(char) * 20);
  int grille_affiche [LARGEUR_G][HAUTEUR_G];
  //initialisation de la grille
  for(int x=0; x<LARGEUR_G; x++)
    for(int y=0; y<HAUTEUR_G; y++)
      grille_affiche[x][y]=-1;
  // recuperation des pieces
  int nb_piece=game_nb_pieces(g);
  cpiece pieces[nb_piece];
  for(int add=0; add<nb_piece; ++add)
    pieces[add]= game_piece(g,add);
  
  //placement des pieces dans la grille
  for(int i=0; i<nb_piece; i++){
    for(int width=0; width<get_width(pieces[i]); width++)
      for(int height=0; height<get_height(pieces[i]); height++)
	grille_affiche[get_x(pieces[i])+width][get_y(pieces[i])+height]=i;
  }

for(int j = HAUTEUR_G-1; j >= 0 ; j--){
  for(int i = 0; i < LARGEUR_G; i++){ 
      sprintf(str, "../imgg/%d.bmp", (int)  grille_affiche[i][j]);
      img_display(w, img, coord, str);
      coord.x += TAILLE_CASE + TAILLE_ESPACE_ENTRE_CASE;
    }
      coord.x = 30;
      coord.y += TAILLE_CASE + TAILLE_ESPACE_ENTRE_CASE;
    }
  display_score(w, g);
  free(str);
  SDL_Flip(w->screen);
}

static void text_display(window w, SDL_Surface* texte, SDL_Color couleur, SDL_Rect coord, char* str, char* police){
  //Initialisation Police de caractère.
  TTF_Font* Police =TTF_OpenFont(police, 30);
  if (police == NULL) {
    printf("Erreur SDL_ttf : %s\n", TTF_GetError());
    exit(1);
  }
  texte = TTF_RenderText_Blended(Police, str, couleur);
  SDL_BlitSurface(texte, NULL, w->screen, &coord);
  TTF_CloseFont(Police);
  SDL_FreeSurface(texte);
  }
void display_score(window w, game g){
  SDL_Rect coord;
  SDL_Surface* img=NULL;
  char* str = malloc(sizeof(char) * 10);
  char* police = malloc(sizeof(char) * 30);
  police = "../imgg/dk_butterfly.otf";
  SDL_Color couleurNoire = {0, 0, 0};

  coord.x = w->size_w - TAILLE_X_SCORE - TAILLE_ESPACE;
  coord.y = 30;
  img_display(w, img, coord, "../imgg/score.bmp");

  coord.x += 20;
  coord.y += 20;
  text_display(w, img, couleurNoire, coord, "Moves :",  police);

  coord.y += 40;
  sprintf(str, "%d",(int)game_nb_moves(g));
  text_display(w, img, couleurNoire, coord, str, police);

  free(str);
}

  int main( int argc, char *argv[ ] ){
    dir d;
    int x;
    int y;

   piece pieces[TAILLE_TAB];
   pieces[0] = new_piece(1, 3, 2, 2, true, true);  //l'ane rouge est en position de partie
   pieces[1] = new_piece(0, 3, 1, 2, true, true);  
   pieces[2] = new_piece(3, 3, 1, 2, true, true);
   pieces[3] = new_piece(0, 1, 1, 2, true, true);
   pieces[4] = new_piece(3, 1, 1, 2, true, true);
   pieces[5] = new_piece(1, 2, 2, 1, true, true);  
   pieces[6] = new_piece(1, 1, 1, 1, true, true);
   pieces[7] = new_piece(2, 1, 1, 1, true, true);
   pieces[8] = new_piece(0, 0, 1, 1, true, true);
   pieces[9] = new_piece(3, 0, 1, 1, true, true);

   window w = new_window();
   game g = new_game(LARGEUR_G, HAUTEUR_G, TAILLE_TAB , pieces);
   bool running=true;
   
   SDL_Rect voitR;
    voitR.x=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_CASE;
    voitR.y=TAILLE_ESPACE;
    voitR.w=150;
    voitR.h=150;

   SDL_Rect voit1;
    voit1.x=TAILLE_ESPACE;
    voit1.y=TAILLE_ESPACE;
    voit1.w=75;
    voit1.h=150;

   SDL_Rect voit2;
    voit2.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3;
    voit2.y=TAILLE_ESPACE;
    voit2.w=75;
    voit2.h=150;

   SDL_Rect voit5;
    voit5.x=TAILLE_CASE+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE;
    voit5.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
    voit5.w=150;
    voit5.h=75;

   SDL_Rect voit3;
    voit3.x=TAILLE_ESPACE;
    voit3.y=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
    voit3.w=75;
    voit3.h=150;

   SDL_Rect voit4;
    voit4.x=TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3+TAILLE_ESPACE;
    voit4.y=TAILLE_ESPACE+TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2;
    voit4.w=75;
    voit4.h=150;

   SDL_Rect voit6;
    voit6.x=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_ESPACE;
    voit6.y=TAILLE_ESPACE+TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3;
    voit6.w=75;
    voit6.h=75;

   SDL_Rect voit7;
    voit7.x=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE;
    voit7.y=TAILLE_ESPACE+TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3;
    voit7.w=75;
    voit7.h=75;

   SDL_Rect voit8;
    voit8.x=TAILLE_ESPACE;
    voit8.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
    voit8.w=75;
    voit8.h=75;

   SDL_Rect voit9;
    voit9.x=TAILLE_ESPACE+TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3;
    voit9.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
    voit9.w=75;
    voit9.h=75;

   Uint32 color= SDL_MapRGB(w->screen->format, 0x00, 0xff, 0xff);

    //Boucle(BASE DU PROGRAMME)
    for(; ;)
      {
	while(running){
          SDL_Event event;
          while(SDL_PollEvent(&event)){
	    switch(event.type){
	      
	    case SDL_QUIT: running= false; break;
	    case SDL_MOUSEMOTION :
	      x= event.motion.x;
	      y= event.motion.y;

	      if(x>voitR.x && x<voitR.x+voitR.w && y>voitR.y && y<voitR.y+voitR.h){
               d= move_event(w, g);
               play_move(g, 0, d, 1);
               if (d==DOWN) {
			voitR.x=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_CASE; // Si avance est à 1 alors on incrémente x
                        voitR.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voitR.x=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_CASE; // Sinon on décrémente x 
                        voitR.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if (d==RIGHT) {
			voitR.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x

		} 
               if(d==LEFT) {
			voitR.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 

		}
	      }

             if(x>voit9.x && x<voit9.x+voit9.w && y>voit9.y && y<voit9.y+voit9.h){
               d= move_event(w, g);
               play_move(g, 9, d, 1);
               if (d==RIGHT) {
			voit9.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voit9.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
		} 
               if(d==LEFT) {
			voit9.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voit9.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
		}
               if (d==DOWN) {
                        voit9.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
                        voit9.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
	      }

            if(x>voit8.x && x<voit8.x+voit8.w && y>voit8.y && y<voit8.y+voit8.h){
               d= move_event(w, g);
               play_move(g, 8, d, 1);
               if (d==RIGHT) {
			voit8.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
                        voit8.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
		} 
               if(d==LEFT) {
			voit8.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
                        voit8.y=TAILLE_ESPACE+TAILLE_CASE*4+TAILLE_ESPACE_ENTRE_CASE*4;
		}
               if (d==DOWN) {
                        voit8.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
                        voit8.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
	      }

            if(x>voit6.x && x<voit6.x+voit6.w && y>voit6.y && y<voit6.y+voit6.h){
               d= move_event(w, g);
               play_move(g, 6, d, 1);
               if (d==DOWN) {
			voit6.x=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_ESPACE; // Si avance est à 1 alors on incrémente x
                        voit6.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit6.x=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE+TAILLE_ESPACE; // Sinon on décrémente x 
                        voit6.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==RIGHT) {
			voit6.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit6.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}    
	      }

           if(x>voit7.x && x<voit7.x+voit7.w && y>voit7.y && y<voit7.y+voit7.h){
               d= move_event(w, g);
               play_move(g, 7, d, 1);
               if(d==DOWN) {
			voit7.x=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE; // Si avance est à 1 alors on incrémente x
                        voit7.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==UP) {
			voit7.x=TAILLE_CASE*2+TAILLE_ESPACE_ENTRE_CASE*2+TAILLE_ESPACE; // Sinon on décrémente x 
                        voit7.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               
               if(d==RIGHT) {
			voit7.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit7.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}          
	      }

           if(x>voit1.x && x<voit1.x+voit1.w && y>voit1.y && y<voit1.y+voit1.h){
               d= move_event(w, g);
               play_move(g, 1, d, 1);
               if (d==DOWN) {
			voit1.x=TAILLE_ESPACE; // Si avance est à 1 alors on incrémente y
                        voit1.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit1.x=TAILLE_ESPACE; // Sinon on décrémente y 
                        voit1.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==RIGHT) {
			voit1.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit1.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}   
	      }

           if(x>voit2.x && x<voit2.x+voit2.w && y>voit2.y && y<voit2.y+voit2.h){
               d= move_event(w, g);
               play_move(g, 2, d, 1);
               if (d==DOWN) {
			voit2.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3; // Si avance est à 1 alors on incrémente y
                        voit2.y+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit2.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3; // Sinon on décrémente y 
                        voit2.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
              if(d==RIGHT) {
			voit2.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
              if(d==LEFT) {
			voit2.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}   
	      }

          if(x>voit3.x && x<voit3.x+voit3.w && y>voit3.y && y<voit3.y+voit3.h){
               d= move_event(w, g);
               play_move(g, 3, d, 1);
               if (d==DOWN) {
			voit3.x=TAILLE_ESPACE; // Si avance est à 1 alors on incrémente y
                        voit3.y+=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit3.x=TAILLE_CASE*3+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE*3; // Sinon on décrémente y 
                        voit3.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==RIGHT) {
			voit3.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit3.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}   
	      }

          if(x>voit4.x && x<voit4.x+voit4.w && y>voit4.y && y<voit4.y+voit4.h){
               d= move_event(w, g);
               play_move(g, 4, d, 1);
               if(d==DOWN) {
			voit4.x=TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3+TAILLE_ESPACE; // Si avance est à 1 alors on incrémente y
                        voit4.y+=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit4.x=TAILLE_CASE*3+TAILLE_ESPACE_ENTRE_CASE*3+TAILLE_ESPACE; // Sinon on décrémente y 
                        voit4.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==RIGHT) {
			voit4.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit4.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}  
	      }

          if(x>voit5.x && x<voit5.x+voit5.w && y>voit5.y && y<voit5.y+voit5.h){
               d= move_event(w, g);
               play_move(g, 5, d, 1);
               if(d==DOWN) {
			voit5.x=TAILLE_CASE+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente y
                        voit5.y+=TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE;
		} 
               if(d==UP) {
			voit5.x=TAILLE_CASE+TAILLE_ESPACE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente y 
                        voit5.y-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE;
		}
               if(d==RIGHT) {
			voit5.x+=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Si avance est à 1 alors on incrémente x
		} 
               if(d==LEFT) {
			voit5.x-=TAILLE_CASE+TAILLE_ESPACE_ENTRE_CASE; // Sinon on décrémente x 
		}  
	      }


	    }
	  }
	
	 //logic && render     
         //SDL_FillRect(w->screen,&voit6,color);// pour coloré les fontoms il faut changer &voit**
         //SDL_Flip(w->screen);
	 display_screen(w,g);
         if( game_over_hr(g) ){
         printf(" ** la partie est finie ** ");
         }
	}
      }

    
    //Libération des surfaces
    delete_game(g); 
    delete_window(w);
    TTF_Quit();
 
    //On quitte SDL 
    SDL_Quit();
    
    return 0 ;
  }

