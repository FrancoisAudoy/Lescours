#include <stdio.h>
#include <stdlib.h>
#include "game.h"
#include "piece.h"
#define TAILLE_TAB 6

void affiche_grille(game g, piece pieces[], int nb_piece){
  int grille_affiche [TAILLE_TAB][TAILLE_TAB];
  //initialisation de la grille
  for(int x=0; x<TAILLE_TAB; x++)
    for(int y=0; y<TAILLE_TAB; y++)
      grille_affiche[x][y]=-1;

  //placement des pieces dans la grille
  for(int i=0; i<nb_piece; i++){
    if(can_move_x(pieces[i])){
      for(int j=0; j<get_width(pieces[i]); j++){
  grille_affiche[get_x(pieces[i])+j][get_y(pieces[i])]=i;
      }
    }   
    if(can_move_y(pieces[i])){
      for(int j=0; j<get_height(pieces[i]); j++){
  grille_affiche[get_x(pieces[i])][get_y(pieces[i])+j]=i;
      }
    } 
  }
  
  //affichage de la grille
  //en partant du point le plus en haut a gauche
  for(int y=TAILLE_TAB-1; y>=0; y--){
    printf("*");
    for(int x=0; x<TAILLE_TAB; x++){
      if(grille_affiche[x][y]==-1)
  printf(" . ");
      else
  printf(" %d ",grille_affiche[x][y]);
    }
    printf("*\n");
  }
}

int main() {
  printf("Rush Hour :\n");
  //Test cr�ation game
  piece pieces[6];
  pieces[0] = new_piece(1, 3, 2, 1, true, false); 
  pieces[1] = new_piece(0, 3, 1, 2, false, true);
  pieces[2] = new_piece(3, 3, 1, 2, false, true);
  pieces[3] = new_piece(1, 0, 1, 3, true, false);
  pieces[4] = new_piece(1, 2, 3, 1, true, false);
  pieces[5] = new_piece(0, 0, 1, 2, false, true);
  printf("Affichage de la premi�re game.\n");
  //cr�ation d'une piece valide.
  game game1 = new_game(TAILLE_TAB, TAILLE_TAB, 5, pieces);
  affiche_grille(game1, pieces, 5);
	
  //Test copie_game()
  printf("Affichage de la copie de game.\n");
  game game2 = new_game(TAILLE_TAB, TAILLE_TAB, 5, pieces);
  copy_game(game1 , game2);
  affiche_grille(game2, pieces, 5);
	
  //Test game_nb_pieces()
  int tmp = game_nb_pieces(game1);
  printf("Voici le nombre de piece : %d\n", tmp);
	
  //Test play_move()
  printf("Premier d�placement d'une piece (piece 0 d�plac�e).\n");
  play_move(game1, 0, RIGHT, 1);
  affiche_grille(game1, pieces, 5);

  //Test play_move() sortie de tableau
  printf("Test avec sortie de tableau sur la gauche (piece 0 de 1 case vers la gauche).\n");
  play_move(game1, 0, LEFT, 1);
  affiche_grille(game1, pieces, 5);

  printf("Test avec sortie de tableau sur la droite (piece 2 de 2 cases vers la droite).\n");
  play_move(game1, 2, RIGHT, 2);
  affiche_grille(game1, pieces, 5);

  printf("Test avec sortie de tableau vers le haut (piece 1 de 1 case vers le haut).\n");
  play_move(game1, 1, UP, 1);
  affiche_grille(game1, pieces, 5);

  printf("Test avec sortie de tableau vers le bas (piece 3 de 1 case vers le bas).\n");
  play_move(game1, 3, DOWN, 1);
  affiche_grille(game1, pieces, 5);

  //Test play_move() collision
  printf("Test de collision gauche. (piece 2 collision avec piece 1)\n");
  play_move(game1,2 , LEFT, 1);
  affiche_grille(game1, pieces, 5);

  printf("Test de collision droite (piece 0 collision avec piece 2).\n");
  play_move(game1,0 , RIGHT, 1);
  affiche_grille(game1, pieces, 5);

  printf("Test de collision vers haut (piece 3 collision avec piece 4).\n");
  play_move(game1, 3 , UP, 2);
  affiche_grille(game1, pieces, 5);

  printf("Test de collision vers bas (piece 1 collision avec piece 4).\n");
  play_move(game1, 1 , DOWN, 3);
  affiche_grille(game1, pieces, 5);
	
  //Test game_piece()
  printf("Test de l'appel d'une piece a partir de game (game_piece()).\n");
  piece piece_test = new_piece_rh(0, 0, true, true);
  piece_test = game_piece(game1, 1);
  printf("pos_gx :%d ; pos_by :%d ; taille :%d ; horizontal :%d\n", get_x(piece_test), get_y(piece_test), get_height(piece_test), is_horizontal(piece_test));
	
  
  //Test nb_moves.
  printf("Nombre de mouvements de la partie : %d\n", game_nb_moves(game1));

  //Test game_width().
  printf("Longueur du tableau de la partie : %d\n", game_width(game1));


  //Test game_height().
  printf("Largeur du tableau de la partie : %d\n",  game_height(game1));

  //Test game_square_piece()
  printf("Numero de la piece a la position 3,3 : %d\n", game_square_piece (game1, 3, 3));

  delete_game(game1);
  delete_game(game2);
  delete_piece(pieces[1]);
  delete_piece(pieces[2]);
  delete_piece(pieces[3]);
  delete_piece(pieces[4]);
  delete_piece(pieces[5]);
  delete_piece(piece_test);

	
	
  return 0;
}
