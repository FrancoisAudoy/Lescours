#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "piece.h"
#include "game.h"

#define HAUTEUR_G 5
#define LARGEUR_G 4
#define TAILLE_TAB 10



void affiche_grille(game g){
  int grille_affiche [LARGEUR_G][HAUTEUR_G];
  //initialisation de la grille
  for(int x=0; x<LARGEUR_G; x++)
    for(int y=0; y<HAUTEUR_G; y++)
      grille_affiche[x][y]=-1;
  // recuperation des pieces
  int nb_piece=game_nb_pieces(g);
  cpiece pieces[nb_piece];
  for(int add=0; add<nb_piece; ++add)
    pieces[add]= game_piece(g,add);
  
  //placement des pieces dans la grille
  for(int i=0; i<nb_piece; i++){
    //if(is_horizontal(pieces[i]))
    for(int width=0; width<get_width(pieces[i]); width++)
      // grille_affiche[get_x(pieces[i])width][get_y(pieces[i])]=i;   
      //else
      for(int height=0; height<get_height(pieces[i]); height++)
	grille_affiche[get_x(pieces[i])+width][get_y(pieces[i])+height]=i;
  }
  
  //affichage de la grille
  //en partant du point le plus en haut à gauche
  for(int y=HAUTEUR_G-1; y>=0; y--){
    printf("*");
    for(int x=0; x<LARGEUR_G; x++){
      if(grille_affiche[x][y]==-1)
	printf(" . ");
      else
	printf(" %d ",grille_affiche[x][y]);
    }
    printf("*\n");
  }
}

int main (){
  int target; int distance;
  char *cmd=(char*) malloc(sizeof(char)*100);
  if(cmd==NULL){
    exit(EXIT_FAILURE);
  }
  piece pieces[TAILLE_TAB];
  pieces[0] = new_piece(1, 3, 2, 2, true, true);  //l'ane rouge est en position de partie
  pieces[1] = new_piece(0, 3, 1, 2, true, true);  
  pieces[2] = new_piece(3, 3, 1, 2, true, true);
  pieces[3] = new_piece(0, 1, 1, 2, true, true);
  pieces[4] = new_piece(3, 1, 1, 2, true, true);
  pieces[5] = new_piece(1, 2, 2, 1, true, true);  
  pieces[6] = new_piece(1, 1, 1, 1, true, true);
  pieces[7] = new_piece(2, 1, 1, 1, true, true);
  pieces[8] = new_piece(0, 0, 1, 1, true, true);
  pieces[9] = new_piece(3, 0, 1, 1, true, true);

  char pPiece[6];
  char pDistance[6];
  
  game game1 = new_game(LARGEUR_G, HAUTEUR_G, TAILLE_TAB , pieces);
   while( !game_over_ar(game1)){
    printf("  -------------------------l'ane rouge----------------------- \n");
    affiche_grille(game1);
    printf("  -------------------------l'ane rouge----------------------- \n");
    printf("Entrez le numéro de la piece :\n");
    scanf("%s2",pPiece);
    target = atoi(pPiece);
    printf("Entrez la direction (haut=UP , bas=DOWN , droite=RIGHT , gauche=LEFT)  :\n");
    scanf("%s5",cmd);
    printf("Entrez le nombre de déplacement :\n");
    scanf("%s1",pDistance);

    distance = atoi(pDistance);
    

    if(strcmp(cmd,"RIGHT") == 0)
        	play_move(game1, target, RIGHT, distance) ;
        else
        	if(strcmp(cmd,"UP") == 0)
        		play_move(game1, target, UP, distance) ;
        	else
        		if(strcmp(cmd,"LEFT") == 0)
        			play_move(game1, target, LEFT, distance) ;
        		else
        			if(strcmp(cmd,"DOWN") == 0)
        				play_move(game1, target, DOWN, distance) ;
        			else
        				fprintf(stderr,"Direction invalide\n");

    
  }
 
  printf("la partie est finie en %d coups!\n",game_nb_moves(game1));
  delete_game(game1) ;
  free(cmd);
  
  return EXIT_SUCCESS;
}
