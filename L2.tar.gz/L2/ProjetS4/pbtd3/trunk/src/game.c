﻿#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include  "game.h"


typedef struct game_s* game;
typedef const struct game_s* cgame;

struct game_s {
  int nb_moves;
  int width;
  int height;
  int nb_pieces;
  piece* tab_pieces;
}game_s;

//revoir pour faire la copie des pieces
game new_game(int width, int height, int nb_pieces, piece *pieces) {

  //Allocationde la structure de la game.
  game new_game = (game)malloc(sizeof(struct game_s));
  if (new_game == NULL) {
    exit(EXIT_FAILURE);
  }

  //Initialisation des variables de la structure de game.
  new_game->width = width;
  new_game->height = height;
  new_game->tab_pieces = pieces;
  new_game->nb_pieces = nb_pieces;
  new_game->nb_moves = 0;

  return new_game;
}

//Libère toutes les cases du tableau de game, tableau et la structure.
void delete_game(game g) {
  for(int i=0; i< g->nb_pieces; ++i)
    delete_piece(g->tab_pieces[i]);
  free(g);
}

// Créer une copie de la game.
void copy_game(cgame src, game dst) {
  dst->nb_moves = src->nb_moves;
  dst->width = src->width;
  dst->height = src->height;
  dst->nb_pieces = src->nb_pieces;
  for(int i=0 ; i<src->nb_pieces ; ++i){
    copy_piece(src->tab_pieces[i], dst->tab_pieces[i]);
  }
}

//Vérifie le nombre de piece en fonction de leur identifiant.
int game_nb_pieces(cgame g) {
  return g->nb_pieces;
}

//Retourne la piece demandée sinon envoie un message d'erreur avec une piece initialise à 0.
cpiece game_piece(cgame g, int piece_num) {
  if (piece_num < game_nb_pieces(g) && piece_num >= 0) {
    return g->tab_pieces[piece_num];
  }
  else {
    piece p = NULL;
    fprintf(stderr,"Erreur du numero de piece!\n");
    return p;
  }
}

//Vérifie la fin de la partie.
bool game_over_hr(cgame g) {
  if (get_x(g->tab_pieces[0])==g->width-2 && get_y(g->tab_pieces[0])== get_y(g->tab_pieces[0])) {
    return true;
  }
  return false;
}

bool game_over_ar(cgame g) {
  if (get_x(g->tab_pieces[0])== (g->width - 1)/2  && get_y(g->tab_pieces[0])==0) {
    return true;
  }
  return false;
}

//Initialisela nouvelle position des pieces dans g->tab_pieces puis dans g->board.
bool play_move(game g, int piece_num, dir d, int distance) {


  if (piece_num >= 0 && piece_num < game_nb_pieces(g)) {
    if(can_move_x(game_piece(g, piece_num))) {
      int x = get_x(game_piece(g, piece_num));
      int y = get_y(game_piece(g, piece_num));
      bool move_x = can_move_x(game_piece(g, piece_num));
      bool move_y = can_move_y(game_piece(g, piece_num));
      int height = get_height(game_piece(g, piece_num));
      int width = get_width(game_piece(g, piece_num));
      //copy sert à vérifier si la nouvelle piece n'entre pas en collision avec celles à proximités.
      piece copy;


      if (d == LEFT) {
	if (distance>=0 && x-distance >= 0) {
	  copy = new_piece(x, y, width, height, move_x, move_y );
	  for(int i=get_x(g->tab_pieces[piece_num]) ; i>=get_x(g->tab_pieces[piece_num])-distance+1; --i){
	    move_piece(copy, LEFT ,1);
	    for(int a = 0 ; a<game_nb_pieces(g) ; ++a){
	      if( g->tab_pieces[a] != g->tab_pieces[piece_num]){
		if( intersect(copy, g->tab_pieces[a])){
		  fprintf(stderr,"Impossible collision avec %d\n",a);
		  delete_piece(copy);
		  return 0;
		}
	      }
	    }	    
	  }
	  
    	  //Libération d'allocation de copy et de l'ancienne version de la piece.
	  delete_piece(copy);
    	  //Allocation de la nouvelle version piece.
	  move_piece(g->tab_pieces[piece_num], LEFT,distance);
          g->nb_moves += distance;
          return 1;
	}
        else{
	  fprintf(stderr,"Impossible sortie du tableau\n");
	  return 0;
        }
      }

      if(d == RIGHT) {
	if (distance>=0 && x + distance + get_width(g->tab_pieces[piece_num])-1 < g->width) {
	  copy = new_piece(x, y, width, height, move_x, move_y );
	  for(int i=get_x(g->tab_pieces[piece_num]) ; i<=get_x(g->tab_pieces[piece_num])+distance-1; ++i){
	    move_piece(copy, RIGHT , 1);
	    for(int a = 0 ; a<game_nb_pieces(g) ; ++a){
	      if( g->tab_pieces[a] != g->tab_pieces[piece_num]){
		if( intersect(copy, g->tab_pieces[a])){
		  fprintf(stderr,"Impossible collision avec %d\n",a);
		  delete_piece(copy);
		  return 0;
		}
	      }
	    }	    
	  }
    	  //Libération d'allocation de copy et de l'ancienne version de la piece.
	  delete_piece(copy);
    	  //Allocation de la nouvelle version piece.
	  move_piece(g->tab_pieces[piece_num], RIGHT,distance);
          g->nb_moves += distance;
          return 1;
	}
        else{
	  fprintf(stderr,"Impossible sortie du tableau\n");
	  return 0;
        }
      }
    }

    if(can_move_y(game_piece(g, piece_num))) {
      int x = get_x(game_piece(g, piece_num));
      int y = get_y(game_piece(g, piece_num));
      bool move_x = can_move_x(game_piece(g, piece_num));
      bool move_y = can_move_y(game_piece(g, piece_num));
      int height = get_height(game_piece(g, piece_num));
      int width = get_width(game_piece(g, piece_num));
      //copy sert à vérifier si la nouvelle piece n'entre pas en collision avec celles à proximités.
      piece copy;


      if (d == UP) {
	if (distance >= 0 && y + distance <= (game_height(g)-get_height(game_piece(g, piece_num)))) {
	 copy = new_piece(x, y, width, height, move_x, move_y );
	  for(int i=get_y(g->tab_pieces[piece_num]) ; i<=get_y(g->tab_pieces[piece_num])+distance-1; ++i){
	    move_piece(copy, UP , 1);
	    for(int a = 0 ; a<game_nb_pieces(g) ; ++a){
	      if( g->tab_pieces[a] != g->tab_pieces[piece_num]){
		if( intersect(copy, g->tab_pieces[a])){
		  fprintf(stderr,"Impossible collision avec %d\n",a);
		  delete_piece(copy);
		  return 0;
		}
	      }
	    }	    
	  }
	  
    	  //Libération d'allocation de copy et de l'ancienne version de la piece.
	  delete_piece(copy);
    	  //Allocation de la nouvelle version piece.
	  move_piece(g->tab_pieces[piece_num], UP,distance);
          g->nb_moves += distance;
          return 1;
	}
        else{
	  fprintf(stderr,"Impossible sortie du tableau\n");
	  return 0;
        }
      }

      if(d == DOWN) {
	if (distance >=0 && y - distance >= 0) {
	  copy = new_piece(x, y, width, height, move_x, move_y );
	  for(int i=get_y(g->tab_pieces[piece_num]) ; i>=get_y(g->tab_pieces[piece_num])-distance+1; --i){
	    move_piece(copy, DOWN ,1);
	    for(int a = 0 ; a<game_nb_pieces(g) ; ++a){
	      if( g->tab_pieces[a] != g->tab_pieces[piece_num]){
		if( intersect(copy, g->tab_pieces[a])){
		  fprintf(stderr,"Impossible collision avec %d\n",a);
		  delete_piece(copy);
		  return 0;
		}
	      }
	    }	    
	  }
	  
    	  //Libération d'allocation de copy et de l'ancienne version de la piece.
	  delete_piece(copy);
    	  //Allocation de la nouvelle version piece.
	  move_piece(g->tab_pieces[piece_num], DOWN,distance);
          g->nb_moves += distance;
          return 1;
	}
        else{
	  fprintf(stderr,"Impossible sortie du tableau\n");
	  return 0;
        }
      }
    }
  }
  fprintf(stderr, "Mauvais numéro de piece ou mauvaise orientation.\n");
  return 1;
}


//Retourne le nombre de moves.
int game_nb_moves(cgame g) {
  return g->nb_moves;
}

//Retourne la longueur de g->board.
int game_width(cgame g){
  return g->width;
}

//Retourne la largeur de g->board.
int game_height(cgame g){
  return g->height;
}

int game_square_piece (cgame g, int x, int y){
  int res;
  for(int i = 0 ; i<game_nb_pieces(g) ; ++i){
    if(get_x(g->tab_pieces[i]) == x && get_y(g->tab_pieces[i])){
      res = i;
    }
  }
  return res;
}
