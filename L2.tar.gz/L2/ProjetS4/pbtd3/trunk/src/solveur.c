#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#include"game.h"
#include"piece.h"

//nombre de caractére maximun sur une ligne
#define TAILLE_MAX_LIGNE 11

//////////
#define TAILLE_TAB 6
/*
 *
 *Le but de ce solveur est de savoir si il est possible de résoudre la configuration d'une partie
 * retourne le nombre de coup s'il est possible de résoudre cette configuration
 * sinon retourne -1
 */

/*
 *la structure de données est une file
 *
 *piece correspond a la piéce deplacée
 *direction correspond à la direction de la piéce
 *plateau correspond à la partie avec les pieces déplacée
 *next pointe sur l'élément suivant
 *
 */
struct file_solveur{
  int num_piece;
  dir direction;
  game plateau;
  struct file_solveur* next;
};

typedef struct file_solveur* solveur;
/*
 *verifie si l'allocation a bien été effectuée
 *si non envoie un message d'erreur et quitte le programme 
 */
void check_alloc(void * alloc, char* fonction){
  if(alloc == NULL){
    fprintf(stderr,"Impossible d'allouer de la memoire dans %s",fonction);
    exit(EXIT_FAILURE);
  }
}
/*
 *crée une copie de la game g et la retourne
 *g est la game a copie
 *retourne la copie de la piece
 */
game create_copy_game(game g){
  int nb_pieces= game_nb_pieces(g);
  piece pieces[nb_pieces];
  for(int i=0; i<nb_pieces; ++i)
    pieces[i]=new_piece(0,0,0,0,0,0);
  game cg=new_game(0,0,nb_pieces,pieces);
  copy_game(g,cg);
  return cg;
  }

/*
 *Renvoie le dernier élément de la file
 */
solveur get_last(solveur solv){
  solveur tmp= solv;
  while(tmp->next != NULL)
    tmp=tmp->next;
  return tmp;
}


/*
 *crée un nouveau solveur et enfile une game
 *g correspond à la game à enfiler
 *direction est la direction de la pièce déplacée
 *piece est le numero de la piéce déplacée
 */
solveur new_solveur(game g, dir direction, int _piece){
  solveur n_solveur= (solveur) malloc(sizeof(struct file_solveur));
  check_alloc(n_solveur, "new_solveur");
  int nb_pieces= game_nb_pieces(g);
  piece pieces[nb_pieces];
  for(int i=0; i<nb_pieces; ++i)
    pieces[i]=new_piece(0,0,0,0,0,0);
  n_solveur->plateau=new_game(0,0,nb_pieces,pieces);
  copy_game(g,n_solveur->plateau);
  n_solveur->direction=direction;
  n_solveur->num_piece= _piece;
  n_solveur->next=NULL;
  return n_solveur;
}

/*ajoute la game passée en parametre à la fin de la file
 *param: premier correspond au premier element de la file
 *g est la game avec la piece deplacée
 *direction est la direction du deplacement de la piece
 *piece est la piece déplacée
 */
void add_game(solveur premier,game g, dir direction, int num_piece){
  solveur tmp= new_solveur(g, direction, num_piece);
  solveur dernier=get_last(premier);
  dernier->next=tmp;
}

/*
 *Verifie les movements possibles pour la pièce dans la partie
 *et la déplace jusqu'à une collision
 * 
 *g correspond à la partie dans laquelle la pièce sera déplacée
 *piece correspond à la piéce a déplacée
 *
 *return la direction si la piece a été déplacé, -1 sinon
 */
dir move(game g, int _piece){
  cpiece p= game_piece(g, _piece);
  if(can_move_x(p) && play_move(g,_piece,RIGHT,1)){
    while(play_move(g,_piece,RIGHT,1));
    return RIGHT;
}
  if(can_move_x(p) && play_move(g, _piece, LEFT, 1)){
    while(play_move(g, _piece, LEFT, 1));
    return LEFT;
  }
  if(can_move_y(p) && play_move(g, _piece, UP,1)){
    while(play_move(g, _piece, UP,1));
    return UP;
  }
  if(can_move_y(p) && play_move(g, _piece, DOWN,1)){
    while(play_move(g, _piece, DOWN,1));
    return DOWN;
  }
  return -1;
}

/*
 *supprime le premier element de la file (FIFO)
 *
 *premier correspond au premier élément de la file
 */
void remove_game(solveur premier){
  if(premier!=NULL){
  delete_game(premier->plateau);
  free(premier);
  }
}

/*
 *supprime tout les éléments contenu dans la file
 *
 *premier correspond au premier élément de la file
 */
void remove_all(solveur premier){
  while(premier!= NULL){
    solveur tmp= premier;
    premier=tmp->next;
    remove_game(tmp);
  }
}

/*
 *Renvoie la game
 *contenu dans le premier élément de la file de la liste
 */
game get_game(solveur premier){
  return premier->plateau;
}

/*
 *Verifie si la copie de la game g après déplacement est la soluton
 *si ce n'est pas la solution la fonction l'ajoute dans la file
 *si c'est la solution la fonction détruit la file et retourne le nombre de coups
 *
 *g correspond à la partie de départ
 */
int resolve_rh(game g){   

  solveur solv= new_solveur(g, -1,-1);//-1 sert à éviter de donner une direction existante
  int num_piece=0;
  int piece_max= game_nb_pieces(g);
  dir _move;
  
  while(!(game_over_hr(g))){

     copy_game(solv->plateau,g);
     _move=move(g,num_piece);

    if(_move!=-1)
      add_game(solv,g, _move, num_piece);

    //change de numero de piece si égale au nombre de pieces retombe à 0 et défile
    if(++num_piece == piece_max){
      num_piece=0;
      solveur tmp= solv;
      solv=tmp->next;
      remove_game(tmp);
    }
      
  }
   int nb_move= game_nb_moves(g);
 
    remove_all(solv);
    free(g);
    return nb_move;
}

/*
 *récupere la configuration du fichier 
 *et créé la game à partir de ce dernier
 */
int main(int argc, char* argv[]){
  if(argc!=3){
    fprintf(stderr," ./solveur <a|r> <filename> \n a: pour une configuration du jeu AneRouge \n r: pour une configuration du jeu RushHour \n filename: fichier de configuration de la partie\n");
    exit(EXIT_FAILURE);
  }

  //recuperation de la config
  char* jeu= argv[1];
  FILE* config=fopen(argv[2], "r");
  if(config == NULL){
    fprintf(stderr, "Imposible d'ouvrir le fichier de configuration\n");
    exit(EXIT_FAILURE);
  }
  
  char str[TAILLE_MAX_LIGNE];
  fgets(str,TAILLE_MAX_LIGNE,config);
  int size_x=atoi(str);
  int size_y=atoi(str+2);//+2 car il y a un espace entre les deux entiers
  fgets(str,TAILLE_MAX_LIGNE,config);
  int nbr_pieces= atoi(str);
  char init_pieces[nbr_pieces* TAILLE_MAX_LIGNE];
  piece pieces[nbr_pieces];
  int x_piece;
  int y_piece;
  int width_piece;
  int height_piece;
  bool move_x;
  bool move_y;
  
  //initialisation des pieces
  for(int i= 0; i<nbr_pieces; ++i){
    fgets(init_pieces,nbr_pieces*TAILLE_MAX_LIGNE,config);
    x_piece=atoi(init_pieces);
    y_piece= atoi(init_pieces+2);
    width_piece= atoi(init_pieces+4);
    height_piece= atoi(init_pieces+6);
    move_x= atoi(init_pieces+8);
    move_y=atoi(init_pieces+10);
    pieces[i]= new_piece(x_piece, y_piece, width_piece, height_piece, move_x, move_y);
  }
 
  int nombre_coup=-1;
  if(strcmp(jeu,"r")==0){
    game game1 = new_game(size_x, size_y, nbr_pieces, pieces);
    nombre_coup=resolve_rh(game1);
  }
   fclose(config);
  printf("%d",nombre_coup);
  return EXIT_SUCCESS;
}
