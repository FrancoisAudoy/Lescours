#include<stdio.h>
#include<stdlib.h>
#include"piece.h"

#define P_PETITE 2
#define P_GRANDE 3



/*structure definie à partir
 *de new_piece_rh dans piece.h
 */
struct piece_s{
  int pos_gx;//point le plus a gauche de la piece
  int pos_by;//point le plus bas de la piece
  int taille;//2 si small= true sinon 3
  int width;
  int height;
  bool horizontal;
  bool move_x;
  bool move_y;
  
};

piece new_piece_rh(int x, int y, bool small, bool horizontal){
  piece p=(piece) malloc(sizeof(struct piece_s));
  if(p==0){
    fprintf(stderr,"l'allocation memoire n'a pas pu etre effectuer.\n");
    exit(EXIT_FAILURE);
  }
  p->pos_gx=x;
  p->pos_by=y;
  p->horizontal=horizontal;
  if(small)
    p->taille=P_PETITE;
  else
    p->taille=P_GRANDE;
  if(horizontal){
    p->width= p->taille;
    p->height=1;
    p->move_x=true;
    p->move_y=false;
  }
  else{
    p->width=1;
    p->height= p->taille;
    p->move_x=false;
    p->move_y=true;
  }
  
  return p;
}

void delete_piece(piece p){
  free(p);
}

void copy_piece(cpiece src, piece dst){
  dst->pos_gx=src->pos_gx;
  dst->pos_by=src->pos_by;
  dst->taille=src->taille;
  dst->horizontal=src->horizontal;
  dst->move_x=src->move_x;
  dst->move_y=src->move_y;
  dst->width=src->width;
  dst->height=src->height;
  
}

void move_piece(piece p, dir d, int distance){
  if((d==UP || d==DOWN)){
    if(d == UP)
      p->pos_by += distance;
    else
      p->pos_by -= distance;
  }
  if((d==LEFT || d==RIGHT)){
    if(d==RIGHT)
      p->pos_gx +=distance;
    else
      p->pos_gx -=distance;
  }
}


bool intersect(cpiece p1, cpiece p2){
  int x_p1= (p1->move_x) ? p1->width:1;
  int y_p1= (p1->move_y) ? p1->height:1;
  int tab_x_p1 [x_p1];
  int tab_y_p1[y_p1];
  
  int x_p2= (p2->move_x) ? p2->width:1;
  int y_p2= (p2->move_y) ? p2->height:1;
  int tab_x_p2 [x_p2];
  int tab_y_p2 [y_p2];

  tab_x_p1[0]=p1->pos_gx;
  tab_y_p1[0]=p1->pos_by;
  tab_x_p2[0]=p2->pos_gx;
  tab_y_p2[0]=p2->pos_by;
  
  for(int i=1; i<p1->taille; ++i){
    if(can_move_x(p1))
      tab_x_p1[i]= i+p1->pos_gx;
    if(can_move_y(p1))
      tab_y_p1[i]= i+p1->pos_by;
  }

  for(int i=1; i<p2->taille; ++i){
    if(can_move_x(p2))
      tab_x_p2[i]= i+p2->pos_gx;
    if(can_move_y(p2))
      tab_y_p2[i]= i+p2->pos_by;
  }
  
  //comparaison des x
  for (int i=0; i<x_p1; ++i)
    for(int j=0; j<x_p2; ++j)
      if(tab_x_p1[i] == tab_x_p2[j])
	//comparaison des y
	for (int y=0; y<y_p1;++y)
	  for(int z=0; z<y_p2;++z)
	    if(tab_y_p1[y] == tab_y_p2[z])
	      return true;
  return false;
}

int get_x(cpiece p){
  return p->pos_gx;
} 

int get_y(cpiece p){
  return p->pos_by;
}

int get_height(cpiece p){
  return p->height;
}

int get_width(cpiece p){
  return p->width;
}

bool is_horizontal(cpiece p){
  return p->horizontal;
}


/////////////////// VERSION 2 /////////////////////////////

bool can_move_x(cpiece p){
  return p->move_x;
}

bool can_move_y(cpiece p){
  return p->move_y;
}

piece new_piece (int x, int y, int width, int height, bool move_x, bool move_y){
  piece p= (piece) malloc(sizeof(struct piece_s));
  if(p==NULL){
    fprintf(stderr," La piece n a pas pu etre alloue");
    exit(EXIT_FAILURE);
  }
  
  p->pos_gx=x;
  p->pos_by=y;
  p->width=width;
  p->height=height;
  p->move_x=move_x;
  p->move_y=move_y;
  p->taille= width*height;
  
  if(width > height)
    p->horizontal= true;
  else
    p->horizontal=false;

  return p;
}
