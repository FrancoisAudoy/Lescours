#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "piece.h"
#include "game.h"

#define TAILLE_TAB 6

void affiche_grille(game g){
  int grille_affiche [TAILLE_TAB][TAILLE_TAB];
  //initialisation de la grille
  for(int x=0; x<TAILLE_TAB; x++)
    for(int y=0; y<TAILLE_TAB; y++)
      grille_affiche[x][y]=-1;
  //recuperation de toute les pieces
  int nb_piece=game_nb_pieces(g);
  cpiece pieces[nb_piece];
  for(int add=0; add<nb_piece;++add)
    pieces[add]=game_piece(g,add);
  
  //placement des pieces dans la grille
  for(int i=0; i<nb_piece; i++){
    if(can_move_x(pieces[i])){
      for(int j=0; j<get_width(pieces[i]); j++){
	grille_affiche[get_x(pieces[i])+j][get_y(pieces[i])]=i;
      }
    }   
    if(can_move_y(pieces[i])){
      for(int j=0; j<get_height(pieces[i]); j++){
	grille_affiche[get_x(pieces[i])][get_y(pieces[i])+j]=i;
      }
    } 
  }
  
  //affichage de la grille
  //en partant du point le plus en haut a gauche
  for(int y=TAILLE_TAB-1; y>=0; y--){
    printf("*");
    for(int x=0; x<TAILLE_TAB; x++){
      if(grille_affiche[x][y]==-1)
	printf(" . ");
      else
	printf(" %d ",grille_affiche[x][y]);
    }
    printf("*\n");
  }
}

int main (){
  //int t[6][6];
  int target, distance;
  char *cmd=(char*) malloc(sizeof(char)*100);
  if(cmd==NULL){
    exit(EXIT_FAILURE);
  }
  piece pieces[6];
  pieces[0] = new_piece(0, 3, 2, 1, true, false);  //1ere piece est en position de partie
  pieces[1] = new_piece(4, 2, 1, 2, false, true);
  pieces[2] = new_piece(3, 3, 1, 2, false, true);
  pieces[3] = new_piece(5, 2, 1, 3, false, true);
  pieces[4] = new_piece(1, 2, 3, 1, true, false);
  pieces[5] = new_piece(0, 0, 1, 2, false, true);

  char pCar[6];
  char pDistance[6];

  printf("  --------------------------RUSH_HOUR------------------------ \n");
  game game1 = new_game(TAILLE_TAB, TAILLE_TAB, 6, pieces);
  while( !game_over_hr(game1) ){

    affiche_grille(game1);
    printf("Entrez le numéro de la voiture :\n");
    scanf("%s1",pCar);
    printf("Entrez la direction (haut=UP , bas=DOWN , droite=RIGHT , gauche=LEFT)  :\n");
    scanf("%s5",cmd);
    printf("Entrez le nombre de déplacement :\n");
    scanf("%s1",pDistance);

    target = atoi(pCar);
    distance = atoi(pDistance);
    
    if(strcmp(cmd,"RIGHT") == 0)
    	play_move(game1, target, RIGHT, distance) ;
    else
    	if(strcmp(cmd,"UP") == 0)
    		play_move(game1, target, UP, distance) ;
    	else
    		if(strcmp(cmd,"LEFT") == 0)
    			play_move(game1, target, LEFT, distance) ;
    		else
    			if(strcmp(cmd,"DOWN") == 0)
    				play_move(game1, target, DOWN, distance) ;
    			else
    				fprintf(stderr,"Direction invalide");
    
  }
 
  printf("la partie est finie en %d coups!\n",game_nb_moves(game1));
  delete_game(game1) ;
  free(cmd);
  
  return EXIT_SUCCESS;
}
