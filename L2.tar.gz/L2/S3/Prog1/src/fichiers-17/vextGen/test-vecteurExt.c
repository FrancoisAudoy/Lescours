#include <stdlib.h>
#include <stdio.h>
#include "vecteurExt.h"

void *creerElement(int n){
  int* p= (int*)&n;
  return p;
}
void afficherElement(void *element){
  int *n= (int*)(&element);
  printf("%d\n",*n);
}


 int main(void){
    vext v= vecteurCreer();
    vecteurAjouter(v, creerElement(10));
    vecteurAjouter(v, creerElement(20));
    vecteurAjouter(v, creerElement(30));
    printf("v: ");
    vecteurIterateur(v,afficherElement);
    printf("\n");
    printf("v apres modification  et ajout: \n");
    vecteurEcrire(2, v, creerElement(40));
    vecteurAjouter(v,creerElement(50));
    printf("v: ");
    vecteurIterateur(v,afficherElement);
    printf("\n");
    vecteurEcrire(10, v, creerElement(60));
    printf("v: ");
    vecteurIterateur(v,afficherElement);
    printf("\n");
    libererV(v);

    return EXIT_SUCCESS;
}
