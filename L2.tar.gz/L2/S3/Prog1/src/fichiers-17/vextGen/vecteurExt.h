#ifndef VECTEUR_EXT_INT_H
#define VECTEUR_EXT_INT_H

typedef struct vecteurExt *vext;
typedef void (*iterateur) (void*);

struct vecteurExt{
  void** contenu;
  long taillePhysique;
  long tailleRallongement;
  long nombreElements;
  void (*liberer)(void*);
};

extern vext vecteurCreer(void);
extern void vecteurLiberer(vext v);
extern void* vecteurLire(int i, vext v);
extern void vecteurEcrire(long i, vext v, void* x);
extern void vecteurAjouter(vext v, void* x);
extern int vecteurNombreElements(vext v);
extern void vecteurAfficher(vext v);
extern void libererV(vext v);
extern void vecteurIterateur(vext v, iterateur f);

#endif /* VECTEUR_EXT_INT_H */


