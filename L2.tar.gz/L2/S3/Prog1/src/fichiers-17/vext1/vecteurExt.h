#ifndef VECTEUR_EXT_INT_H
#define VECTEUR_EXT_INT_H

typedef struct vecteurExtInt *vextInt;

struct vecteurExtInt{
  int* contenu;
  long taillePhysique;
  long tailleRallongement;
  long nombreElements;
};

extern vextInt vecteurCreer(void);
extern void vecteurLiberer(vextInt v);
extern int vecteurLire(int i, vextInt v);
extern void vecteurEcrire(long i, vextInt v, int x);
extern void vecteurAjouter(vextInt v, int x);
extern int vecteurNombreElements(vextInt v);
extern void vecteurAfficher(vextInt v);

#endif /* VECTEUR_EXT_INT_H */


