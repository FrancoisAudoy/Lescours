#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"vecteurExt.h"

#define TAILLE_PHYSIQUE 1
#define TAILLE_RALLONGEMENT 2

vextInt vecteurCreer(void){
  vextInt v= (vextInt)malloc(sizeof(struct vecteurExtInt));
  if(v== NULL){
    fprintf(stderr,"probleme d'allocation");
    exit(EXIT_FAILURE);
  }
  v->contenu=(int*) malloc(sizeof(int)*TAILLE_PHYSIQUE);
  if(v->contenu == NULL){
    fprintf(stderr,"probleme d'allocation");
    exit(EXIT_FAILURE);
  }
  v->taillePhysique= TAILLE_PHYSIQUE;
  v->tailleRallongement= TAILLE_RALLONGEMENT;
  v->nombreElements=0;
  return v;
}

void vecteurLiberer(vextInt v){
  if(v!=NULL){
    if(v->contenu!=NULL)
      free(v->contenu);  
    free(v);
  }
}

int vecteurLire(int i, vextInt v){
  if(i>v->nombreElements){
    fprintf(stderr,"indice hors du tableau");
    exit(EXIT_FAILURE);
  }
  return v->contenu[i];
}

void vecteurEcrire(long i, vextInt v, int x){
  if (i < 0){
    fprintf(stderr,"erreur en ecriture\n");
    exit(EXIT_FAILURE);
  }
  if(i  >= v->taillePhysique)  // il faut rallonger 
    {
      long  l= v->taillePhysique;
      while(i >= l){
	l+= v->tailleRallongement;
	v->tailleRallongement *= 2;
      }
      printf(" rallongement <%ld> -> <%ld> \n",  v->taillePhysique, l ); 
      v->contenu= (int*)realloc(v->contenu,l * (sizeof(int)));
      if (v->contenu == NULL){
            fprintf(stderr,"probleme de reallocation\n");
            exit(EXIT_FAILURE);
        }
      memset(v->contenu + v->taillePhysique, 0, (l - v->taillePhysique)*sizeof(int));
      v->taillePhysique= l;
    }
  v->contenu[i]= x;
  if(v->nombreElements < i+1)
    v->nombreElements= i+1;
}

void vecteurAjouter(vextInt v, int x){
  vecteurEcrire(v->nombreElements+1,v, x);
  
}


int vecteurNombreElements(vextInt v){
  return v->nombreElements;
}

void vecteurAfficher(vextInt v){
  for(int i=0; i<(v->nombreElements);i++){
    printf("%d:%d ",i, v->contenu[i]);
  }
  printf("\n");
}
