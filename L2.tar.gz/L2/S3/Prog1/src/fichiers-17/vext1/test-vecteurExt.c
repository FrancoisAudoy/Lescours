#include <stdlib.h>
#include <stdio.h>

#include "vecteurExt.h"

int
main(void)
{
    vextInt v= vecteurCreer();
    vecteurAjouter(v, 10);
    vecteurAjouter(v, 20);
    vecteurAjouter(v, 30);
    printf("v: ");
    vecteurAfficher(v);
    printf("\n");
    printf("v apres modification  et ajout: \n");
    vecteurEcrire(2, v, 40);
    vecteurAjouter(v, 50);
    printf("v: ");
    vecteurAfficher(v);
    printf("\n");
    vecteurEcrire(10, v, 60);
    printf("v: ");
    vecteurAfficher(v);
    printf("\n");
    vecteurLiberer(v);

    return EXIT_SUCCESS;
}
