#ifndef TRANSFO_SUITE_H_
#define TRANSFO_SUITE_H_

typedef int (*p_fct)(int);

typedef struct option {
  char fct[5];
  p_fct p_Fct;
} option;

int carre(int k);
int cube(int k);
p_fct rechercherOption(char *s);
int *appliquer (p_fct f , int tab[], int taille );
void afficherTableau(int t[],int taille);

#endif
