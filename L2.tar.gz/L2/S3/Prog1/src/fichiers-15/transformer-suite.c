#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"transfo-suite.h"



  
int carre(int k){
  return k*k;
}

int cube(int k){
  return k*k*k;
}

option tabOption[2]={{"carre",carre},{"cube",cube}};

p_fct rechercherOption(char *s){
  for (int i=0; i<2; i++){
    if(strcmp(tabOption[i].fct,s))
      return tabOption[i].p_Fct;
  }
  return NULL;
}

int *appliquer (p_fct f , int tab[], int taille ){
  int *tabRet = (int*) malloc(taille* sizeof(int));
  if(tabRet== NULL){
    fprintf(stderr,"probleme d allocation");
    exit(EXIT_FAILURE);
  }
  
  for(int i=0; i<taille; i++){
    tabRet[i]=f(tab[i]);
  }

  return tabRet;
}

void afficherTableau(int t[],int taille){
  for(int i = 0; i<taille; i++)
    printf("%d ", t[i]);
  printf("\n");
}
