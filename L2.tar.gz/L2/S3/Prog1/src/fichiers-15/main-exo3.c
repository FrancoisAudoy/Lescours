#include"transfo-suite.h"
#include<stdlib.h>
#include<stdio.h>
static void
usage(char *s){
  printf("Usage : ./%s (carre|cube) <liste d'entiers>\n", s);
  exit (EXIT_FAILURE);
}

int
main(int argc, char *argv[]){
  if (argc <3)
    usage(argv[0]);

  int taille= argc-2;
  int t[taille];
  for ( int i =0 ; i<taille ; i++)  
    t[i] = atoi(argv[i+2]);
  afficherTableau(t, taille);
  
  p_fct f = rechercherOption(argv[1]);
  if (f == NULL)
    usage(argv[0]);
  int *t1= appliquer(f, t, taille);
  afficherTableau(t1, taille);

  return EXIT_SUCCESS;
}

  
