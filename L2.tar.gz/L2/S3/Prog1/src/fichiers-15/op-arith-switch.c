#include <stdio.h>  
#include <stdlib.h>
typedef int (*p_fct)(int,int);

int somme(int i, int j){
    return i+j;
}
 
int multiplication(int i, int j){
    return i*j;
}
 
int quotient(int i, int j){
    return i/j;
}
 
int modulo(int i, int j){
    return i%j;
}

static void saisie(int *a, int *b, int* operateur, char *argv[]){
    *a = atoi(argv[1]);
    *b = atoi(argv[2]);
    *operateur = atoi(argv[3]);
}

int main(int argc, char *argv[]){
  int i, j, opCode;
  p_fct p_result[4]={somme,multiplication,quotient,modulo};
  saisie(&i, &j, &opCode, argv);
  if (opCode<4 && opCode >=0){


    /*int result;
    switch(opCode){
    case 0 : result = somme(i,j); break;
    case 1 : result = multiplication(i,j); break;
    case 2 : result = quotient(i,j); break;
    case 3 : result = modulo(i,j); break;
    }*/
    printf("\nResultat : %d.\n", p_result[opCode](i,j));
  }
  else
    printf("\nMauvais numero de fonction. \n");
  return EXIT_SUCCESS;
}
