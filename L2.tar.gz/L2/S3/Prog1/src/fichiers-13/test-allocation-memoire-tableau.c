#include <stdlib.h>
#include <stdio.h>
#include "tableau.h"

static void
usage(char * commande){
    fprintf(stderr,"%s <taille du tableau d'entiers> \n", commande);
    exit(EXIT_FAILURE);
}


int
main(int argc, char*argv[])
{
    if (argc != 2)
        usage(argv[0]);
    
    int* tab;
    int* copie;
    int taille = atoi(argv[1]);
    
    // On demande d'allouer la memoire pour le tableau
    tab = (int*) malloc(taille * sizeof(int));
    copie =(int*) malloc (taille * sizeof(int));
    // On verifie si la memoire a ete allouee
    if (tab == NULL) {
        fprintf(stderr, "probleme d'allocation\n");
        return EXIT_FAILURE;
    }
    if(copie== NULL){
      fprintf(stderr,"probleme d'allocation\n");
      return EXIT_FAILURE;
    }
    
    // Utilisation de la memoire
    for (int i=0; i<taille; i++)
        tab[i] = i;
    for(int i=0; i<taille; i++)
      copie[i]=tab[i];
    if(doubler(tab, taille, taille))
      printf("La fonction doubler a echouer\n");
    for (int i=0; i<taille; i++)
      printf("tab[%d]=%d  copie[%d]=%d\n", i, tab[i],i, copie[i]);
    tab= (int*) realloc(tab, (taille*2) *sizeof(int));
    if(tab== NULL){
      fprintf(stderr,"probleme d'allocation\n");
      return EXIT_FAILURE;
    }
      
    tab[taille]=0;
    for(int i=0; i<taille; i++)
      tab[taille] += tab[i];
    printf("tab[%d]=%d\n",taille, tab[taille]);
    
    // On n'a plus besoin de la memoire, on la libere
    free(tab);
    free(copie);
    
    return EXIT_SUCCESS;
}
