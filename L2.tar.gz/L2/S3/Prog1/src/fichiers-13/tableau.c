#include <stdio.h>
#include <stdlib.h>
#include "tableau.h"

int lireElemTableau(int, int[], int, int*);
int ecrireElemTableau( int, int , int[], int );
int afficherTableau (int[], int, int);
void afficherToutTableau(int []);
int ajouterElemTableau( int , int [], int *);
int echangerElemTableau(int , int , int[], int );
int maximum(int, int[], int, int*);
int indiceMinimum(int ,int[], int, int*);

/*
 *Retourne 0 si reussi
 *Retourne 1 si indice en dehors du tableau
 *
 */

int lireElemTableau(int ix, int t[], int nbelem, int *elem){
  if(ix<=nbelem && ix >= 0){
   *elem= t[ix];
    return 0;
  }
  else
    return 1;
}


/*
 *Renvoi 0 si reussi
 *Renvoi 1 si indice en dehors du tableau
 * 
*/

int ecrireElemTableau(int ix, int val, int t[], int nbelem){
  if (ix<=nbelem && ix>=0){
    t[ix]= val;
    return 0;
  }
  else
    return 1;
}


/*
 *Renvoi 0 si reussi
 *Renvoi 1 si nbr a lire trop grand
 *
 */

int  afficherTableau (int t[], int nbelem, int n){
  if (n<=nbelem && n>=0){
    for( int i=0; i<n ; i++){
      printf("a l indice %d la valeur est : %d\n",i,t[i]);
    }
    return 0;
  }
  else
    return 1;
}
  
void afficherToutTableau(int t[]){
  for (int i=0; i<TAILLE; i++){
    printf("indice %d valeur %d\n",i, t[i]);
  }
  return;
}



/*
 *renvoi 0 si reussi
 *renvoi 1 si tableau plein
 *
 */
int ajouterElemTableau(int val , int t[], int *nbelem){
  if (*nbelem < TAILLE ){
    t[*nbelem+1]=val;
      *nbelem= *nbelem+1;
    return 0;
  }
  else
    return 1;
}



/*
 *renvoi 0 si reussi
 *renvoi 1 si indice pas correct
 *
 */
int echangerElemTableau(int ind1, int ind2, int t[], int nbelem){
  if ((ind1 != ind2) && (ind1<= nbelem && ind2<= nbelem)){
    int tmp= t[ind1];
    t[ind1]= t[ind2];
    t[ind2]= tmp;
    return 0;
  }
  else
    return 1;
}

int doubler(int tab[], int taille, int nbrElemADoubler){
  if(nbrElemADoubler > taille)
    return 1;
  for(int i=0; i<nbrElemADoubler; i++)
    tab[i]= tab[i] *2;
  return 0;
}
   

/*
 *renvoi 0 si reussi
 *renvoi 1 si n vaut 0
 *renvoi 2 si n trop grand pour tableau
 */

/*int maximum(int n , int t[], int nbelem, int *max){
  if (n >0 && n<= nbelem){
    for (int i=0 ; i< n; i++){
      if(*max < t[i])
	*max=t[i];
    } 
	return 2;
    }
}*/
  
