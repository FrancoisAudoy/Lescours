#include <stdlib.h>
#include <stdio.h>

int main(void)
{
    int* memoireAllouee;
    
    // On demande d'allouer la memoire
    memoireAllouee = (int*) malloc(sizeof(int));
    // On verifie si la memoire a ete allouee
    if (memoireAllouee == NULL) {
        fprintf(stderr, "probleme d'allocation");
        return EXIT_FAILURE;
    }
    // Utilisation de la memoire allouee
    *memoireAllouee = 10;
    printf("adresse = %p, valeur = %d\n", memoireAllouee, *memoireAllouee);
    
    // On n'a plus besoin de la memoire, on la libere
    free(memoireAllouee);
    
    return EXIT_SUCCESS;
}
