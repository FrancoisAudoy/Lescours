#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"MinMax.h"


void minMax1(int tab[], int taille, int *min, int *max){
  *min=tab[0];
  *max=*min;
  for(int i=0; i<taille; i++){
    if(tab[i] < *min)
      *min= tab[i];
    if(*max<tab[i])
      *max=tab[i];
  }
}
	
void minMax2(int tab[], int taille, MinMax * mm){
  for(int i=0; i<taille; i++){
    if(tab[i] < mm-> min)
      mm->min= tab[i];
    if(mm->max<tab[i])
      mm->max=tab[i];
  }
}

void minMax3(int tab[], int taille,int mm[]){
  mm[INDMIN]=tab[0];
  mm[INDMAX]=tab[0];
  for(int i=0; i<taille; i++){
    if(tab[i] < mm[INDMIN])
      mm[INDMIN]= tab[i];
    if(mm[INDMAX]<tab[i])
      mm[INDMAX]=tab[i];
  }
}

MinMax *minMax4(int tab[], int taille){
  MinMax *p_mm;
  p_mm=(MinMax*) malloc(sizeof(MinMax));
  if(p_mm==NULL){
    fprintf(stderr,"probleme d alocation\n");
    exit(EXIT_FAILURE);
  }
  for(int i=0; i<taille; i++){
    if(tab[i] < p_mm-> min)
     p_mm->min= tab[i];
    if(p_mm->max<tab[i])
      p_mm->max=tab[i];
  }
  return p_mm;
}

int * minMax5(int tab[], int taille){
  int *p_entier;
  p_entier=(int*) malloc(2*sizeof(int));
  if(p_entier == NULL){
    fprintf(stderr, "probleme d allocation \n");
    exit(EXIT_FAILURE);
  }
  p_entier[INDMIN]=tab[0];
  p_entier[INDMAX]=tab[0];
  for(int i=0; i<taille; i++){
    if(tab[i] <p_entier[INDMIN])
      p_entier[INDMIN]= tab[i];
    if(p_entier[INDMAX]<tab[i])
      p_entier[INDMAX]=tab[i];
  }
  return p_mm;
}




  
