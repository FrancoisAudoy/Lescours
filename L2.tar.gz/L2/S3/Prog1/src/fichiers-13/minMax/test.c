#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"MinMax.h"


int main(int argc, char* argv[]){
  if(argc!=2){
    fprintf(stderr,"%s <taille du tableau>\n", argv[0]);
    return EXIT_FAILURE;
  }
  int min, max;
  MinMax s;
  int tab[2], *tabD;
  MinMax *mm;

  int taille= atoi(argv[1]);
  int tableau[taille];
  
  srand(time(NULL));
  for (int i=0; i<taille; i++){
    tab[i]=rand()%100;
   }
  for(int i=0; i<taille; i++){
    printf("tableau[%d]=%d\n",i,tableau[i]);
  }
  minMax1(tableau, taille, &min, &max);
  printf("minMax1: min: %d max: %d\n",min,max);
  minMax2(tableau,taille,&s);
  printf("minMax2: min: %d max: %d\n",s.min,s.max);
  minMax3(tableau,taille,tab);
  printf("minMax3: min : %d max: %d\n", tab[INDMIN],tab[INDMAX]);
  mm=minMax4(tableau,taille);
  printf("minMax4: min : %d max: %d\n", mm->min, mm->max);
  tabD=minMax5(tableau,taille);
  printf("minMax5: min : %d max: %d\n", tabD[INDMIN], tabD[INDMAX]);

  free(mm);
  free(tabD);
  return EXIT_SUCCESS;
 }
