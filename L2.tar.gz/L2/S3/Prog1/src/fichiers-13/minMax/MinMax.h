#ifndef _MINMAX_H_
#define _MINMAX_H_
#define INDMIN 0
#define INDMAX 1

struct MinMax{
  int min;
  int max;
};

typedef struct MinMax MinMax;

void minMax1(int tab[], int taille, int *min, int *max);
void minMax2(int tab[], int taille, MinMax * mm);
void minMax3(int tab[], int taille,int mm[]);
MinMax *minMax4(int tab[], int taille);
int * minMax5(int tab[], int taille);
#endif
