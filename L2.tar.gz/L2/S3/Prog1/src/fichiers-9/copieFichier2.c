#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, char * argv[]){
  FILE *src, *dest;
  char n[30], s[100];
  src=fopen("fichier.txt","r");
  if (src== NULL){
    printf("le fichier source n'a pas pu etre ouvert");
  }
  else {
    printf("nouveau fichier : ");
    scanf("%s", n);
    for(int i= 0; i<sizeof(n); i++){
      if (isupper(n[i])){
	n[i]=tolower(n[i]);
	}
    }
    dest=fopen(n, "w");
    if (dest == NULL)
      printf("le fichier source n a pas pu etre ouvert");
    else{
      while (!feof(src)){
	fgets(s, 99, src);
	fputs(s,dest);
      }
      fclose(src);
      fclose(dest);
    }
  }
}
