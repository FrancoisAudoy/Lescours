#include <stdio.h>
#include <stdlib.h> 

void f1(char* s[], int* t, int n) {
  for(int i = 0; i < n; i++) 
    printf("%s a %d ans.\n", s[i], t[i]);
  printf("---\n");
}

void f2(char* s[], int* t, int n) {
  int* p_t= t;
  char** p_s= s;
  for(int i = 0; i < n; i++) 
    printf("%s a %d ans.\n",  *(p_s+i), *(p_t+i));
  printf("---\n"); 
}

void f3(char* s[], int* t, int n){
  int* p_t= t;
  char** p_s= s;
  for(int i = 0; i < n; i++) 
    printf("%s a %d ans.\n",  p_s[i], p_t[i]);
  printf("---\n"); 
}

void f4(char* s[], int* t, int n){
  int* p_t;
  char** p_s;
  for(p_t= t, p_s= s; p_t - t < n; p_t++, p_s++)
	printf("%s a %d ans.\n", *p_s, *p_t);
}


int main(int argc, char *argv[])
{
  if(argc==0){
    printf("il faut rentrer nom age ...");
    return EXIT_FAILURE;
  }
  int ages[30];
  char *noms[200];
  for (int i=1; i<=argc; i++){
    if((i%2)==0){
      ages[i]=*argv[i];
    }
    else{
      noms[i]=argv[i];
    }
  }
      
  int n = sizeof(ages) / sizeof(int);
  f1(noms, ages, n);
  f2(noms, ages, n);
  f3(noms, ages, n);
  f4(noms, ages, n);
  return EXIT_SUCCESS;
}
