#include <stdio.h>
#include <stdlib.h>

#define TAILLE 5


int 
main(void){
  int t[] = {10, 20, 30, 40, 50};
  int *p = t;
  int x = *p + 1;
  printf("%d %d \n", *p, x);
  afficherToutTableau(t);
  *p +=1;
  p++;
  ++*p;
  printf("%d %d \n", *p, x);
  afficherToutTableau(t);
  int y = (*p)++;
  printf("%d %d %d\n", *p, x, y);
  afficherToutTableau(t);
  x = *p++;
  printf("%d %d %d\n", *p, x, y);
  afficherToutTableau(t);
  return EXIT_SUCCESS;
}
