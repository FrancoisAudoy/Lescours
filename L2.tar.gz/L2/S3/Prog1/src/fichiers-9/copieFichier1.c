#include <stdio.h>
#include <stdlib.h>

int main(void){
  FILE *f, *g;
  char s[100], n;
  f=fopen("fichier.txt","r");
  if(f==NULL){
    printf("fichier non existant\n");
  }
  else{
    printf("nom fichier : ");
    scanf("%s", &n);
    printf("\n");
    g=fopen(&n,"w");
    if (g ==NULL){
      printf("le nouveau fichier n'a pas pu etre ouvert");
    }
    else{
      
      while(!feof(f)){
	fgets(s,99,f);
	fputs(s,g);
      }
    }
  }
  fclose(f);
  fclose(g);
}
  
