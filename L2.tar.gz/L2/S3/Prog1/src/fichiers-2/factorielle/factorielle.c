#include <stdio.h>
#include <stdlib.h>

extern unsigned  long int factorielleIterative (int);

int main (void){

  printf("%lld ", factorielleIterative(20));
  return EXIT_SUCCESS;
}


unsigned  long int factorielleIterative(int fact){
  int result=1;

  for (int i= 1; i<=fact ; i++){

    result=result * i;
  }
  return result;
}
