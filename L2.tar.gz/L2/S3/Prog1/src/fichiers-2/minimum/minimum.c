#include <stdio.h>
#include <stdlib.h>
extern int min(int, int);

int main(void) {

  int resultmin1 , resultmin2;

  resultmin1= min(10,50);
  resultmin2= min (50,10);

  printf(" resultat1 : %d \n resultat2 : %d \n", resultmin1, resultmin2);
  return EXIT_SUCCESS;
}

int min(int a, int b) {
  if(a<b){
    return a;
  }
  else{
    return b;
  }
  
}

  
