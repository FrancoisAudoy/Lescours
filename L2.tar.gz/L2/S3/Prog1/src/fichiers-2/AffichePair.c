#include <stdio.h>
#include <stdlib.h>

int main (void){

  for (int pairs = 2; pairs <=100 ; pairs= pairs+2){
    printf("%d ", pairs);
  }
  
  return 0;
}
