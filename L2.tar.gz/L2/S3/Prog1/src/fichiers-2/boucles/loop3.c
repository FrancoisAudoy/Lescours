#include <stdio.h>
#include <stdlib.h>  

int main(void){

  for (int i=1 ; i<=10 ; i=i+1);
    printf("%d ", i);
  printf("\n");

  return EXIT_SUCCESS;
}
