#include <stdio.h>
#include <stdlib.h>  

int main(void){

  for (int  i=100 ; i>0 ; i=i+1)
    printf("%d ", i);
  printf("\n");

  return EXIT_SUCCESS;
}
