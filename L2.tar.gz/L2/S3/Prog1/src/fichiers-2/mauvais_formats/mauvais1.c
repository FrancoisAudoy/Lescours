#include <stdio.h>
#include <stdlib.h>  

int main(void){
    int  nbre = 5;
    printf("%.2f \n", nbre);
    return EXIT_SUCCESS;
}
