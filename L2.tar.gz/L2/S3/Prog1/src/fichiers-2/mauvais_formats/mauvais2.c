#include <stdio.h>
#include <stdlib.h>  

int main(void){
  double prix = 12.3;
  printf("%d \n", prix);
  return EXIT_SUCCESS;
}
