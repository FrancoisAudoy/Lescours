#include <stdio.h>
#include <stdlib.h>

#define PI 3.14

extern float perimetre(int);

int main(void){

  for(int i=1; i<=10; i++){
    printf("%d ",(int) perimetre(i));
  }
  
  return EXIT_SUCCESS;
}

float perimetre(int r){
  return 2*r*PI;
}
