#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int nbre = 5;
    double prix = 12.3;
    long result1 = prix * nbre;
    long double result2 = prix * nbre;
    
    printf("Nombre  |%09d|\nPrix    |%09.4f| \n", nbre, prix);
    printf("Total 1 |%09ld| \n", result1);
    printf("Total 2 |%09.1Lf| \n", result2);
    return EXIT_SUCCESS;
}
