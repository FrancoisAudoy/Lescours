#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(void){
  int a=1, b=2, c=1;
  int delta = (b*b)-(4*a*c);
  float result1=0, result2=0;
  
  if(delta < 0){
    printf("Pas de solution");
  }
  if(delta == 0){
    result1=(-b / (2*a));
    printf("solution de delta = 0 :\nresult1: %f", result1);
  }
  if(delta > 0){
    result1=( (-b + sqrt(delta)) / (2*a));
    result2=( (-b - sqrt(delta)) / (2*a));
    printf("2 solutions pour delta >0 :\nresult1: %f\nresult2: %f", result1, result2);
  }
  return EXIT_SUCCESS;
}
