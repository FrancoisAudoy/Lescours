#include <stdio.h>
#include <stdlib.h>  

#define N -10

int main(void){

  int p2 = 1;
  int i=0;
  /*  completer en utilisant l'instruction for */ 
  do{
   p2= p2*2;
   i= i+1;
  }while(i<= (unsigned int)N);
  printf("%d\n",p2);

  return EXIT_SUCCESS;
}
