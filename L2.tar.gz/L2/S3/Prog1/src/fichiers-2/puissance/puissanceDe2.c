#include <stdio.h>
#include <stdlib.h>  

#define N 10

int main(void){

  int p2 = 1;

  /*  completer en utilisant l'instruction for */ 
  for (int i=0; i<=N ; i++){
   p2= p2*2;
  }
  printf("%d\n",p2);

  return EXIT_SUCCESS;
}
