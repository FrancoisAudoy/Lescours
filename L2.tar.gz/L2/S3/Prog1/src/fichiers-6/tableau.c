#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TAILLE 15 

extern int lireElemTableau(int, int[], int, int*);
extern int ecrireElemTableau( int, int , int[], int );
extern int afficherTableau (int[], int, int);
extern void afficherToutTableau(int []);
extern int ajouterElemTableau( int , int [], int *);
extern int echangerElemTableau(int , int , int[], int );
extern int maximum(int, int[], int, int*);
extern int indiceMinimum(int ,int[], int, int*);

int main (int argc, char *argv[]){

  int tab[TAILLE], indicex= 5, valInd, valajouter= 12, nbElement=0;
  int valRetFct, retFctEcrire;
  int indech1= 9, indech2= 5;
  int nbpourmax= 9, max, indmini;

  // remplissage du tableau avec des valeur aleatoire
  srand(time(NULL));
  for (int i=0; i<TAILLE-5; i++){
    tab[i]=rand()%100;
    nbElement++;
   }

  printf(" ***********Avant la fonction ecrire ************* \n");
  valRetFct=lireElemTableau(indicex, tab, nbElement, &valInd);
  if(valRetFct==0){
    printf("La valeur du tableau a l indice %d est : %d\n", indicex, valInd);
  }
  else{
    printf("l indice preciser n est en dehor de la limite du tableau \n");
  }
  
  printf(" ********Fonction ecrire ****************\n");
  retFctEcrire= ecrireElemTableau(indicex, valajouter, tab, nbElement);
  if (retFctEcrire ==0){
  valRetFct=lireElemTableau(indicex, tab, nbElement, &valInd);
   printf("Apres la fonction ecrire, la valeur du tableau a l indice %d est : %d\n", indicex, valInd);
  }
  else{
    printf("l indice preciser n est en dehor de la limite du tableau \n");
  }
  
  printf("******** FONCTION AFFICHERTABLEAU******** \n");
  valRetFct=afficherTableau(tab, nbElement, 2);
  if (valRetFct != 0)
    printf("une erreur s est produite");
  
  printf("************ FONCTION AFFICHERTOUTTABLEAU **********************\n"); 
  afficherToutTableau(tab);

  printf("************* FONCTION AJOUTERELEMTABLEAU *******************\n");
  valRetFct= ajouterElemTableau (valajouter, tab, &nbElement);
  if(valRetFct == 0){
    printf("indice %d valeur %d \n", nbElement, tab[nbElement]);
  }
  else
    printf("une erreur s est produite\n");


  printf("************FONCTION ECHANGER ELEMENT TABLEAU************\n");
  valRetFct=echangerElemTableau(indech1, indech2, tab, nbElement);
  if(valRetFct== 0)
    afficherTableau(tab, nbElement, nbElement);
  else
    printf("une erreur s'est produite");

  printf("************ FONCTION MAXIMUM****************\n");
  valRetFct=maximum(nbpourmax,tab, nbElement, &max);
  if (valRetFct ==0)
    printf("la valeur max pour %d nombre du tableau est %d\n", nbpourmax, max);
  else
    printf("une erreur s'est produite\n");

  printf("**************FONCTION INDICE MINIMUM********************");
  valRetFct= indiceMinimum(nbpourmax,tab, nbElement, &indmini);
  if (valRetFct ==0)
    printf("la valeur max pour %d nombre du tableau est %d\n", nbpourmax, indmini);
  else
    printf("une erreur s'est produite\n");
  
  return EXIT_SUCCESS;
}

/*
 *Retourne 0 si reussi
 *Retourne 1 si indice en dehors du tableau
 *
 */

int lireElemTableau(int ix, int t[], int nbelem, int *elem){
  if(ix<=nbelem && ix >= 0){
   *elem= t[ix];
    return 0;
  }
  else
    return 1;
}


/*
 *Renvoi 0 si reussi
 *Renvoi 1 si indice en dehors du tableau
 * 
*/

int ecrireElemTableau(int ix, int val, int t[], int nbelem){
  if (ix<=nbelem && ix>=0){
    t[ix]= val;
    return 0;
  }
  else
    return 1;
}


/*
 *Renvoi 0 si reussi
 *Renvoi 1 si nbr a lire trop grand
 *
 */

int  afficherTableau (int t[], int nbelem, int n){
  if (n<=nbelem && n>=0){
    for( int i=0; i<n ; i++){
      printf("a l indice %d la valeur est : %d\n",i,t[i]);
    }
    return 0;
  }
  else
    return 1;
}
  
void afficherToutTableau(int t[]){
  for (int i=0; i<TAILLE; i++){
    printf("indice %d valeur %d\n",i, t[i]);
  }
  return;
}



/*
 *renvoi 0 si reussi
 *renvoi 1 si tableau plein
 *
 */
int ajouterElemTableau(int val , int t[], int *nbelem){
  if (*nbelem < TAILLE ){
    t[*nbelem+1]=val;
      *nbelem= *nbelem+1;
    return 0;
  }
  else
    return 1;
}



/*
 *renvoi 0 si reussi
 *renvoi 1 si indice pas correct
 *
 */
int echangerElemTableau(int ind1, int ind2, int t[], int nbelem){
  if ((ind1 != ind2) && (ind1<= nbelem && ind2<= nbelem)){
    int tmp= t[ind1];
    t[ind1]= t[ind2];
    t[ind2]= tmp;
    return 0;
  }
  else
    return 1;
}


/*
 *renvoi 0 si reussi
 *renvoi 1 si n vaut 0
 *renvoi 2 si n trop grand pour tableau
 */

int maximum(int n , int t[], int nbelem, int *max){
  if (n >0 && n<= nbelem){
    for (int i=0 ; i< n; i++){
      if(*max < t[i])
	*max=t[i];
    }
    return 0;
  }
  else{
    if (n<=0)
      return 1;
    if(n>nbelem)
      return 2 ;
  }
}


/*
 *renvoi 0 si reussi
 *renvoi 1 si n vaut 0
 *renvoi 2 si n trop grand
 *
 */

int indiceMinimum(int n ,int t[],int nbelem, int *indicemini){
  int min;
    if (n >0 && n<= nbelem){
      for(int i=0; i<n; i++){
	if(min>t[i]){
	  min=t[i];
	  *indicemini=i;
	}
      }
    }
    else{
      if(n<=0)
	return 1;
      if (n>nbelem)
	return 2;
    }
}
  
