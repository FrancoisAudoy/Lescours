#include<stdlib.h>
#include<stdio.h>

int **initTabDeTabs(int m){
  int **tab;
  int valtab=1;
  tab=(int **)malloc(m*sizeof(int*));
  for(int i=0; i<m; i++){
    *tabs[i]=(int*)malloc((i+1)*sizeof(int));
    if(tabs[i]==NULL){
      fprintf(stderr,"probleme d allocation");
      exit(EXIT_FAILURE);
    }
      for(int j=0; j<(i+1); j++,valtab++){
      *tabs[j]=valtab;
    }
  }
}

int main(void){
  int **p_initTabDeTabs;
  p_initTabDeTabs=initTabDeTabs(4);
  for(int i=0; i<4; i++)
    printf("%d",*p[i]);
  
  return EXIT_SUCCESS;
