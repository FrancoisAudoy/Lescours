#include <stdio.h>
#include <stdlib.h>

struct Personne{
  int age[30];
  char *nom[100];
};

typedef struct Personne personne;

void afficherNomAges(personne *p, int nbrpersaffiche){
  for(int i=0; i<nbrpersaffiche; i++){
    printf("Nom : %s   Age : %u\n",p->nom[i], p->age);
  }
  printf("---\n");
}

int main (int argc, char *argv[]) {
  if(argc%2==0){
    printf("erreur dans argumment : \n Nom Age\n");
    return EXIT_FAILURE;
  }
  personne pers;
  int nbrpers= argc-2;
  int indage=0, indnom=0;
  for(int i = 1; i<=argc-1; i++){
    if(i%2==0){
      pers.age[indage]=atoi(argv[i]);
      indage++;
    }
    else{
      pers.nom[indnom]=argv[i];
      indnom++;
    }
  }
  afficherNomAges(&pers, nbrpers);
}
