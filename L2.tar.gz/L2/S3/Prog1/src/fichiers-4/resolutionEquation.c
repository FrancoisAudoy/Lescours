#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]){
  //si il manque un argument ou si il y en a trop
  if (argc!=4){
    fprintf(sterr,"%s entier entier entier \n",argv[0]);
    exit(EXIT_FAILURE); 
  }
  int a=atoi(argv[1]), b=atoi(argv[2]), c=atoi(argv[3]);
  //calcul du delta
  int delta = (b*b)-(4*a*c);
  float result1=0, result2=0;
  // recherche de solution en fonction du delta
  if(delta < 0){
    printf("Pas de solution\n");
  }
  if(delta == 0){
    result1=(-b / (2*a));
    printf("solution de delta = 0 :\nresult1: %f\n", result1);
  }
  if(delta > 0){
    result1=( (-b + sqrt(delta)) / (2*a));
    result2=( (-b - sqrt(delta)) / (2*a));
    printf("2 solutions pour delta >0 :\nresult1: %f\nresult2: %f\n", result1, result2);
  }
  return EXIT_SUCCESS;
}
