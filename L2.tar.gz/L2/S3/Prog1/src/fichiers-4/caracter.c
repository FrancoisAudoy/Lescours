#include<stdio.h>
#include <stdlib.h>
#include<stdbool.h>
#include <ctype.h>

extern bool estChiffre(int);
extern bool estLettre (int);
extern int enMajuscule(int);

int main (int argc , char *argv[]) {
  if (argc != 2){
    fprintf(stderr, "%s caractere \n", argv[0]);
    exit(EXIT_FAILURE);
  }
  int caract= atoi(argv[1]);
  // printf("%s  %d", argv[1]);
  
  //verifie si c est un chiffre
  if(estChiffre(caract)== true){
    printf("c'est un chiffre\n");
  }
  else{
    printf("Ce n est pas un chiffre\n");
  }
  
   //verifie si c est une lettre
   if (estLettre(caract)==true){
     printf("c est une lettre\n");
   //transforme en Majuscule
     printf(" Transformation en majuscule : \n %s ---------> %s\n ", caract, enMajuscule(caract));
   }
   else{
     printf("ce n est pas une lettre\n");
   }
 
  return EXIT_SUCCESS;
}

//renvoie Vrai si chiffre 
bool estChiffre(int c){
  if(((c>=0 && c<=9) && !estLettre(c))){
    return true;
  }
  else{
    return false;
  }
}
//renvoie Vrai si caractere 
bool estLettre(int c){
  if (((c<=atoi("z") && c>=atoi("a")) || (c<=atoi("Z") && c>=atoi("A")))){
    return true;
  }
  else
    return false;
}

int enMajuscule(int c){
  return toupper (c);
}
