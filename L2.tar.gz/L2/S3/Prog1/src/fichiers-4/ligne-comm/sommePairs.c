#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]){
  int somme;
  for(int i=1; i<argc; i++) {
    if((atoi(argv[i])%2) == 0){
      somme= somme + atoi(argv[i]);
    }
  }
  printf("La somme des nombres paire est egal a : %d \n", somme);
}
