#include <stdio.h>
#include <stdlib.h>

int 
main(int argc, char *argv[]){
  printf("on a lance %s \n", argv[0]);
  printf("avec %d parametres: ", argc-1);
  for( int i=1 ; i<argc ; i++)
    printf("%s ", argv[i]);
  printf("\n");
  return EXIT_SUCCESS;
}
