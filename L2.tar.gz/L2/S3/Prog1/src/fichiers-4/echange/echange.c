#include <stdio.h>
#include <stdlib.h>

void echange(int a, int b) {
    int temp = b;
    b = a;
    a = temp;
}

int
main(void){
    int a = 3;
    int b = 5;
    
    printf("avant echange : a=%d, b=%d\n", a, b);
    echange(a,b);
    printf("après echange : a=%d, b=%d\n", a, b);
    

    return EXIT_SUCCESS;
}
