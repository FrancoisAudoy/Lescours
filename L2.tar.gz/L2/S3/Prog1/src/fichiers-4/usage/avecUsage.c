#include <stdlib.h>
#include <stdio.h>

static void
usage(char * commande){
  fprintf(stderr,"%s entier entier \n", commande);
  exit(EXIT_FAILURE);
}

int 
max(int a, int b){
  return (a>b)?a:b;
}

int 
main(int argc, char * argv[]){
  if (argc != 3)
    usage(argv[0]);
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  printf("le max est %d\n", max(a,b));
  return EXIT_SUCCESS;
}
