#include <stdlib.h>
#include <stdio.h>

int 
max(int a, int b){
  return (a>b)?a:b;
}

int 
main(int argc, char * argv[]){
  if (argc != 3)
    exit(EXIT_FAILURE);
  int a = atoi(argv[1]);
  int b = atoi(argv[2]);
  printf("le max est %d\n", max(a,b));
  return EXIT_SUCCESS;
}
