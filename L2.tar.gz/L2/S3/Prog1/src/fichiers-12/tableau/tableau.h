#define TAILLE 10

int lireElemTableau(int, int[], int, int*);
int ecrireElemTableau( int, int , int[], int );
int afficherTableau (int[], int, int);
void afficherToutTableau(int []);
int ajouterElemTableau( int , int [], int *);
int echangerElemTableau(int , int , int[], int );
int maximum(int, int[], int, int*);
int indiceMinimum(int ,int[], int, int*);
