#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include"tableau.h"

#define TAILLE 10

int main (int argc, char *argv[]){

  int tab[TAILLE], indicex= 5, valInd, valajouter= 12, nbElement=0;
  int valRetFct, retFctEcrire;
  int indech1= 2, indech2= 4;

  // remplissage du tableau avec des valeur aleatoire
  srand(time(NULL));
  for (int i=0; i<TAILLE-5; i++){
    tab[i]=rand()%100;
    nbElement++;
   }

  printf(" ***********Avant la fonction ecrire ************* \n");
  valRetFct=lireElemTableau(indicex, tab, nbElement, &valInd);
  if(valRetFct==0){
    printf("La valeur du tableau a l indice %d est : %d\n", indicex, valInd);
  }
  else{
    printf("l indice preciser n est en dehor de la limite du tableau \n");
  }
  
  printf(" ********Fonction ecrire ****************\n");
  retFctEcrire= ecrireElemTableau(indicex, valajouter, tab, nbElement);
  if (retFctEcrire ==0){
  valRetFct=lireElemTableau(indicex, tab, nbElement, &valInd);
   printf("Apres la fonction ecrire, la valeur du tableau a l indice %d est : %d\n", indicex, valInd);
  }
  else{
    printf("l indice preciser n est en dehor de la limite du tableau \n");
  }
  
  printf("******** FONCTION AFFICHERTABLEAU******** \n");
  valRetFct=afficherTableau(tab, nbElement, 2);
  if (valRetFct != 0)
    printf("une erreur s est produite");
  
  printf("************ FONCTION AFFICHERTOUTTABLEAU **********************\n"); 
  afficherToutTableau(tab);

  printf("************* FONCTION AJOUTERELEMTABLEAU *******************\n");
  valRetFct= ajouterElemTableau (valajouter, tab, &nbElement);
  if(valRetFct == 0){
    printf("indice %d valeur %d \n", nbElement, tab[nbElement]);
  }
  else
    printf("une erreur s est produite\n");


  printf("************FONCTION ECHANGER ELEMENT TABLEAU************\n");
  valRetFct=echangerElemTableau(indech1, indech2, tab, nbElement);
  if(valRetFct== 0)
    afficherTableau(tab, nbElement, nbElement);
  else
    printf("une erreur s'est produite\n");
  
  return EXIT_SUCCESS;
}
