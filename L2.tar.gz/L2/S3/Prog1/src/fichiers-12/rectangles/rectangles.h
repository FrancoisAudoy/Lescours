#define RECT_VALIDE 0
#define ERR_RECT 1

struct rectangle{
  int longueur;
  int largeur;
};

typedef struct rectangle rectangle;

int saisirRectangle(rectangle *r, int longu, int larg);
int modificationlongueur(rectangle *r, int longu);
int modificationLargeur(rectangle *r, int larg);
int calculerPermetre(rectangle *r);
void afficherRectangle(rectangle *r);
int largeurRectangle(rectangle *r);
int longueurRectangle(rectangle *r);
int calculAire(rectangle *r);
bool estCarre(rectangle *r);
bool plusLargeQueLong(rectangle *r);
void tournerRectangle(rectangle *r);
