#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "rectangles.h"

int main(void){
  int longueur, largeur;
  FILE *f;
  rectangle r;
  char chaine[10];

  f=fopen("rectangle.txt", "r");
  if(f==NULL){
    printf("le fichier n a pas pu etre ouvert");
    exit(EXIT_FAILURE);
  }

  while (!feof(f)){
      fgets(chaine,9,f);
      largeur= atoi(chaine);
      fgets(chaine,9,f);
      longueur = atoi(chaine);
      if(saisirRectangle(&r, longueur, largeur)){
	printf("Dimension invalide");
      }
      else
	afficherRectangle(&r);
    }
    fclose(f);
}
