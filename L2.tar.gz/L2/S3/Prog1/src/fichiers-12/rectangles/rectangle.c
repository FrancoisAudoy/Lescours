#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "rectangles.h"



int saisirRectangle(rectangle *r, int longu, int larg){
  if(larg>0 && longu>0){
  r->longueur=longu;
  r->largeur=larg;
  return RECT_VALIDE;
 }
  return ERR_RECT;
}

int modificationlongueur(rectangle *r, int longu){
  if(longu>0){
    r->longueur=longu;
    return RECT_VALIDE;
  }
  return ERR_RECT;
}


int modificationLargeur(rectangle *r, int larg){
  if(larg>0){
    r->largeur=larg;
    return RECT_VALIDE;
  }
  return ERR_RECT;
}

int calculerPermetre(rectangle *r){
  int result;
  result=(r->longueur+r->largeur)*2;
  return result;
}

void afficherRectangle(rectangle *r){
  printf("longueur : %d  Largeur : %d\n", r->longueur, r->largeur);
}

int largeurRectangle(rectangle *r){
  return r->largeur;
}

int longueurRectangle(rectangle *r){
  return r->longueur;
}

int calculAire(rectangle *r){
  return (r->longueur * r->largeur);
}

bool estCarre(rectangle *r){
  return (r->longueur == r->largeur);
}

bool plusLargeQueLong(rectangle *r){
  return (r->largeur>r->longueur);
}

void tournerRectangle(rectangle *r){
  int tmp;
  tmp=r->longueur;
  r->longueur=r->largeur;
  r->largeur=tmp;
}
