#include<stdio.h>
#include<stdlib.h>
#include"rationnels.h"


int pgcd(int a, int b){
  if(b==0 )
    return a ;
  
  return pgcd(b,a%b);
}

void normalisationRationnel(rationnel *r){
  if(!r->num)
    r->den=1;
  else{
    int pg = pgcd(abs(r->num), abs(r->den));
    r->num /= pg;
    r->den /= pg;
  }
}

int creerRationnel(int a, int b, rationnel *r){
  if(!b)
    return ERR_RATIONNEL;
  r->num=b>0?a:-a;
  r->den=abs(r->den);
  normalisationRationnel(r);
  return RATIONNEL_CORRECT;
}

int calculerOposerRationnel(rationnel *r){
  return((r->num*(-1))/r->den);
}


int claculerInverseRationnel(rationnel *r){
  return(r->den/r->num);
}

int calculerAdditionRationnel(rationnel *r1, rationnel *r2){
  if (r1->den != r2->den){
     int addnum, addDen;
    addDen= r1->den * r2->den;
    addnum = ((r1->num*addDen) + (r2->num*addDen));
    return (addnum/addDen);
    
  }
  return( (r1->num+r2->num)/r1->num);
}


int main(int argc, char *argv[]){
  /* if(argc!=3){
    printf("il manque des arguments");
    exit(EXIT_FAILURE);
    }*/
  int num=12 , den= 15;
  rationnel p_r;

  /*num=atoi(argv[1]);
    den=atoi(argv[2]);*/
  int ratcorrect = creerRationnel(num,den,&p_r);
  if (ratcorrect){
    printf("le nombre rationnel est incorrect\n");
    exit(EXIT_FAILURE);
  }
  else{
    printf("numerateur %d denominateur %d\n", p_r.num, p_r.den);
    printf("rationnel oppose %d\n", calculerOposerRationnel(&p_r));
  }
}
  
