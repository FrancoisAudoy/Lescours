#define ERR_RATIONNEL 1
#define RATIONNEL_CORRECT 0

struct rationnel {
  int num;
  int den;
};

typedef struct rationnel rationnel;

void normalisationRationnel(rationnel *r);
void normalisationRationnel(rationnel *r);
int calculerOposerRationnel(rationnel *r);
int claculerInverseRationnel(rationnel *r);
int calculerAdditionRationnel(rationnel *r1, rationnel *r2);
