#include <stdio.h>
#include <stdlib.h>

int *f(int n) {
  int *t=(int*)malloc(n*sizeof(int));
  for (int i = 0; i < n; i++){
    t[i] = 1;
  }
  return t;
}

void g(int v) {
}

int main(void) {
  int *tab = f(10);
  for(int i=0; i<10; i++)
  printf("%d\n", tab[i]);
  g(4);
  printf("%d\n", *tab);
  return EXIT_SUCCESS;
}

