 #include<stdio.h>
int main(void){
	for(int machin=0;machin<10;machin++)
		{
 			int truc=2*machin+1;
			printf("%d\n",truc);
		}
	return 0;
}

