#include <stdio.h>
#include <stdlib.h>

int main (void){
  int a=0;
  int b=0;
  int c=0;


  printf("Entrez la valeur de a\n");
  scanf("%d" ,&a);
  printf("entrez la valeur de b\n");

  if(a>b && a>c){
    printf("a est la valeur superieur\n");
  }
   if(b>a && b>c){
      printf(" b est la valeur superieur\n");
  }
   if(c>a && c>b){
     printf("c est la valeur superieur\n");
   }

   /* if(a==b || b==c || a==c){
     printf("des valeurs sont égales\n");
     }*/

   return EXIT_SUCCESS;
}
