#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a = 2;
    if ( a == 2 )
        printf ("Other than 0");
    else
        printf ("Equal to 0");
    return EXIT_SUCCESS;
}
