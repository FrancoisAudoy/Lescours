#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    if (4%2) {
        printf("impair");
    }
    else{
        printf("pair");
    }
    return EXIT_SUCCESS;
}
