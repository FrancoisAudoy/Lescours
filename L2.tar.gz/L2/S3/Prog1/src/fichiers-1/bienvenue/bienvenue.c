/* 
premier programme a tester
*/


#include <stdlib.h>
#include <stdio.h>

int main(void)
{
    printf("Bienvenue en Licence 2 !");
    return EXIT_SUCCESS;
}
