#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdbool.h>

#define CHAINE_LONGUEUR_MAX 50
#define CARACTERE_A_REMPLACER 'i'
#define CARACTERE_DE_REMPLACEMENT 'o'
#define CHAINE_DE_TEST "Kilimandjaro"
#define CHAINE_DE_TEST_2 "kayak"


/* renvoie la longueur de la chaine s */
int chaineLongueur(const char s[]);

/* retourne le nombre d'occurrences du caractere c dans s */
int chaineCompterOccurrences(const char s[], char c);

/* dans s remplace toutes les occurrences du caractere c1 par le caractere c2 */
void chaineRemplacerOccurrences(char s[], char c1, char c2);

/* teste si une chaine est palindrome */
bool estPalindrome(const char s[]);

/* copie la chaine src dans la chaine dst  */
char *chaineCopier(char dest[], const char src[]);

/* concatene la chaine de s2 a s1 */
char *chaineConcatener(char s1[], const char s2[]);

/* transforme toutes les lettres de la chaine s en majuscules */
char *chaineVersMajuscules(char s[]);

/* transforme toutes les lettres de la chaine s en minuscules */
char *chaineVersMinuscules(char s[]);

/* compare les deux chaines s1 et s2 */
int chaineComparer(const char s1[], const char s2[]);

/* appelle chaineComparer et affiche les résultats - fonction donnée
   à la fin */
void testComparaison(const char s1[], const char s2[]);


int main(void) {
  char chaine[] = CHAINE_DE_TEST;

  if (chaineLongueur(chaine) != strlen(chaine)){
    fprintf(stderr, "Le test de coherence de longueur_chaine a echoue\n");
    return EXIT_FAILURE;
  }
  int nb1 = chaineCompterOccurrences(chaine, CARACTERE_A_REMPLACER);
  int nb2 = chaineCompterOccurrences(chaine, CARACTERE_DE_REMPLACEMENT);
  printf("chaine initiale : \"%s\"\n", chaine);
  printf("nombre d'occurrences de %c : %d\n", CARACTERE_A_REMPLACER, nb1);
  printf("nombre d'occurrences de %c : %d\n", CARACTERE_DE_REMPLACEMENT, nb2);
  
  char chaine1[] = CHAINE_DE_TEST_2;

  printf( "%s %s un palindrome\n",chaine,estPalindrome(chaine)?"est":"n'est pas");
  printf( "%s %s un palindrome\n",chaine1,estPalindrome(chaine1)?"est":"n'est pas");


  char chaine2[CHAINE_LONGUEUR_MAX];  
  strcpy(chaine2, chaine);  
  chaineRemplacerOccurrences(chaine2, CARACTERE_A_REMPLACER, CARACTERE_DE_REMPLACEMENT);
  printf("chaine apres remplacement de %c par %c :\n \"%s\"\n",
	 CARACTERE_A_REMPLACER, CARACTERE_DE_REMPLACEMENT, chaine2);
  if (chaineCompterOccurrences(chaine2, CARACTERE_A_REMPLACER) != 0) {
    fprintf(stderr, "certains caracteres n'ont pas ete remplaces\n");
    return EXIT_FAILURE;
  }
  if (nb1 + nb2 != chaineCompterOccurrences(chaine2, CARACTERE_DE_REMPLACEMENT)) {
    fprintf(stderr, "Le test de coherence a echoue\n");
    return EXIT_FAILURE;
  }
 
  chaineCopier(chaine2, chaine);
  if (strcmp(chaine2, chaine) != 0){
    fprintf(stderr, "Le test de coherence de chaineCopier a echoue\n");
    return EXIT_FAILURE;
  }
  printf("concatenation de %s et %s : ",chaine2,chaine1);
  chaineConcatener(chaine2,chaine1);
  printf("%s\n",chaine2);

  printf("chaine initiale : \"%s\"\n", chaine);
  chaineCopier(chaine2, chaine);
  chaineVersMajuscules(chaine2);
  char chaine3[CHAINE_LONGUEUR_MAX];
  chaineCopier(chaine3, chaine);
  chaineVersMinuscules(chaine3);
  printf("chaine correspondante en majuscule : \"%s\", en minuscule : \"%s\"\n",chaine2, chaine3);
  if (strcasecmp(chaine2,chaine3) != 0 || strcmp(chaine2,chaine3) == 0){
    fprintf(stderr, "Le test de coherence de a echoue\n");
    return EXIT_FAILURE;
  }
  testComparaison(chaine, chaine);
  testComparaison(chaine, chaine1);
  testComparaison(chaine1, chaine);

  fprintf(stderr, "Test passe avec succes\n");  
  return EXIT_SUCCESS;
}

void testComparaison(const char s1[], const char s2[]){
  printf("comparaison de %s et %s :\n ", s1, s2);
  int entier = chaineComparer(s1,s2);
  if (entier){
    printf("%s %s de %s\n",s1,(entier<0)? "est plus petit":"est plus grand", s2);
  }
  else{
    printf("%s et %s sont identiques\n", s1, s2);
  }
}

int chaineLongueur(const char s[]){
  int longueur=0;
  while(*s++!='\0'){
    longueur++;
  }
  return longueur;
}

int chaineCompterOccurrences(const char s[], char c){
  int nbrOccurence=0;
  while(*s++!='\0'){
    if(*s==c)
      nbrOccurence++;
  }
  return nbrOccurence;
}

void chaineRemplacerOccurrences(char s[], char c1, char c2){
  char *p=s;
  while(*p++!='\0'){
    if(*p==c1){
      *p=c2;
    }
  }
}

bool estPalindrome(const char s[]){
  int i=0, j=chaineLongueur(s);

  while (i<=j){
    if (*s+i == *s+j){
      i++;
      j--;
    }
    else
      return false;
  }
  return true;
}

char *chaineCopier(char dest[], const char src[]){
  char *pdest, *psrc;
  pdest=dest;
  psrc=src;
  while(*psrc++!='\0'){
    *pdest=*psrc;
    pdest++;
  }
  return pdest;
}
  
