#include <stdio.h>
#include <stdlib.h>

void afficheTriangleNombre(int *s, int taille){
  for(int i=taille; i>0; i--){
    *(s+i)=NULL;
    for(int aff=0; aff<i; aff++){
      printf("%d ",*(s+aff));
    }
    printf("\n");
  }
}

int main (void){
  int tab[]={10,20,30,40,50,60};
  afficheTriangleNombre(tab, (sizeof(tab)/sizeof(int)));

  return 0;
}
  
