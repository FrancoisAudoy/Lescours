#include <stdio.h>
#include<stdlib.h>
#include <string.h>

void
afficheTriangle(char* s){
  for(int i= strlen(s); i>0; i--){
    s[i]= '\0';
    printf("%s\n",s);
  }
}

int main(void) {
  char tab[]="Bonjour";
  afficheTriangle(tab);
  
  return EXIT_SUCCESS; 
}
