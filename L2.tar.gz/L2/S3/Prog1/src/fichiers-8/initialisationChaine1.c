#include<stdio.h>
#include<stdlib.h>

int main(int argc, char * argv[]){
  
  char *chaine = "bateau";
  printf("la chaine est: %s\n", chaine);
  *chaine = 'r';
  printf("la chaine est: %s\n", chaine);
  return EXIT_SUCCESS;
}
