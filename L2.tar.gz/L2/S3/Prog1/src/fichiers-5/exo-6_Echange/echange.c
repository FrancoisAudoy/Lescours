#include<stdio.h>
#include<stdlib.h>

extern void echange1(int, int);
extern void echange2(int *, int *);
extern void echange3(int *, int *);
extern void echange4(int *, int *);

int main(int argc, char *argv[]){
  int x= 2, y= 9;

  echange1(x,y);
  printf("echange 1 x %d y %d\n", x,y);
  echange2 (&x, &y);
  printf("echange 2 x %d y %d\n", x,y);
  echange3(&x, &y);
  printf("echange 3 x %d y %d\n", x,y);
  echange4(&x, &y);
  printf("echange 4 x %d y %d\n", x,y);

  return EXIT_SUCCESS;
}

void echange1(int x, int y){
  int tmp;
  tmp=x;
  x=y;
  y=tmp;
}

void echange2(int *x, int *y){
  int tmp;
  tmp=*x;
  *x=*y;
  *y=tmp;
}

void echange3(int *x, int *y){
  int *tmp=NULL;
  tmp=x;
  x=y;
  y=tmp;
}

void echange4(int *x, int *y){
   int *tmp;
  *tmp=*x;
  *x=*y;
  *y=*tmp;
  } 
