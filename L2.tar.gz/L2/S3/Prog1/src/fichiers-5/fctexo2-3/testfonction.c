#include<stdio.h>
#include <stdlib.h>

extern int f1(int *);
extern int f2(int *);
extern int f3 (int *);
extern void h1(int , int);
extern void h2(int *, int *);
extern void h3(int *, int *);
extern void h4(int **, int **);

int main (int argc, char *argv[]){
  int f= 4, h=9;
  int *pf=&f, *ph=&h;

  //********Exercice 2***********
  f=f1(&f);
  f2(&f);
  printf("la valeur de f est maintenant : %d \n",f);
  printf("la valeur de f en retour de f3 est : %d\n",f3(&f));

  //********Exercice 3***********
  h1(f,h);
  printf("la valeur de f et h apres h1-> f %d h %d \n", f, h);
  h2(&f,&h);
  printf("la valeur de f et h apres h2-> f %d h %d \n", f, h);
  h3(&f,&h);
  printf("la valeur de f et h apres h3-> f %d h %d \n", f, h);
  h4(&pf, &ph);
  printf("la valeur de f et h apres h4-> f %d h %d \n", f, h);

  printf("les pointeur pf et ph : pf %a ph %a", pf , ph );
  


  
  return EXIT_SUCCESS;
}


//********Exercice 2***********
int f1(int *i){
  return (*i) +1;
}

int f2(int *i){
  return ++*i;
}

int f3(int *i){
  return *i++;
}


//********Exercice 3***********
void h1(int i , int j){
  i=j;
}

void h2(int *i , int *j){
  i=j;
}

void h3(int *i , int *j){
  *i=*j;
}

void h4(int **i , int **j){
  **i=**j;
  printf("%a %a", i,j);
  *i=*j;
}
