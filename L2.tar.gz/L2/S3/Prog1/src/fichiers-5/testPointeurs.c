
#include <stdio.h>
#include <stdlib.h>
int main (void) {
    double f = 134486.156;
    int p;
    p=&f;
    printf("Contenu de p =%d\n", p) ;
    return EXIT_SUCCESS;
}