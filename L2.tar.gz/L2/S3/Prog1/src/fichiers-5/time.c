#include <stdio.h>
#include <stdlib.h>

extern void hms_to_spm(int,int,int, int*);
extern void spm_to_hms( int, int *, int*,int*,int*);

int main(int argc, char argv[]){
  if(argc!=4){
    printf("il faut 4 argument");
    return EXIT_FAILURE;
  }

  int heure=argv[1], minutes=argv[2], secondes=argv[3];
  int spm;
  hms_to_spm(heure, minutes, secondes,&spm); 
