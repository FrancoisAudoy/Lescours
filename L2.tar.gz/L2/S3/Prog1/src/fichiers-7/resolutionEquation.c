#include <stdlib.h>
#include <stdio.h>
#include <math.h>

void resolution( float a, float b, float c, float **s1, float **s2){
//calcul du delta
  int delta = (b*b)-(4*a*c);
  //float result1=0, result2=0;
  // recherche de solution en fonction du delta
  if(delta < 0){
    *s1=NULL;
    *s2=NULL;
  }
  if(delta == 0){
    **s1=(-b / (2*a));
    *s2=NULL;
    //printf("solution de delta = 0 :\nresult1: %f\n", result1);
  }
  if(delta > 0){
    **s1=( (-b + sqrt(delta)) / (2*a));
    **s2=( (-b - sqrt(delta)) / (2*a));
    //printf("2 solutions pour delta >0 :\nresult1: %f\nresult2: %f\n", result1, result2);
  }
}



int main(int argc, char *argv[]){
  //si il manque un argument ou si il y en a trop
  if (argc!=4){
    //fprintf(sterr,"%s entier entier entier \n",argv[0]);
    exit(EXIT_FAILURE); 
  }
  float a=atof(argv[1]), b=atof(argv[2]), c=atof(argv[3]);
  float s1, s2;
  float *ps1=&s1, *ps2=&s2;
  resolution (a,b,c,&ps1,&ps2);
  if(ps1==NULL){
   printf("Il n y a pas de solution\n");
  }
  else{
   if(ps2==NULL){
    printf("l equation a une solution : %f\n", *ps1);
   }
   else{
    printf("l equation a deux solution s1: %f, s2: %f\n", *ps1, *ps2);
   }
  }



 /*//calcul du delta
  int delta = (b*b)-(4*a*c);
  float result1=0, result2=0;
  // recherche de solution en fonction du delta
  if(delta < 0){
    printf("Pas de solution\n");
  }
  if(delta == 0){
    result1=(-b / (2*a));
    printf("solution de delta = 0 :\nresult1: %f\n", result1);
  }
  if(delta > 0){
    result1=( (-b + sqrt(delta)) / (2*a));
    result2=( (-b - sqrt(delta)) / (2*a));
    printf("2 solutions pour delta >0 :\nresult1: %f\nresult2: %f\n", result1, result2);
  }*/
  return EXIT_SUCCESS;
}
