#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


#define TAILLE 5

bool f1(int *t, int n){
  //int n =sizeof(t)/sizeof(int);
  printf("dans f1 %d  \n", n);
  for(int i=1 ; i<n ; i++)
    if ( *(t+i) > *(t+i-1) )
      return false;
  return true;
}

void afficherToutTableau( int tab[], int n){
  //int n= sizeof(tab)/sizeof(int);
  for (int i=0; i<n; i++){
    printf ("%d\n",tab[i]);
  }
}


int main(int argc, const char *argv[]){
  int t[argc-1] ;
  for (int i=1 ; i<argc; i++){
    t[i-1]= atoi(argv[i]);
  }
  int n = sizeof(t)/sizeof(int);
  printf("dans le main %d\n",n);
  afficherToutTableau(t,n);
  printf("%s decroissant \n\n",f1(t,n)?"est":"n'est pas");

  return EXIT_SUCCESS;
}
