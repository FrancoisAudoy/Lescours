#include <stdio.h>
#include <stdlib.h>

int 
incr(int *i){
  return ++*i;
}

int 
main(void){
  int x=0;
  
  printf("%d \n",incr(&x));
  return EXIT_SUCCESS;
}
