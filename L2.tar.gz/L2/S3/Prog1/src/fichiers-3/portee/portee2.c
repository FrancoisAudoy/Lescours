#include <stdio.h>
#include <stdlib.h>

int a = 1;

void f(void) {
  a++;
}

void g(void) {
  int a = 10;
  a++;
}

void affiche (void) {
  printf("%d\n", a);
}

int main(void) {
  affiche();
  f();
  affiche();
  f();
  affiche();
  g();
  affiche();
  return EXIT_SUCCESS;
}
