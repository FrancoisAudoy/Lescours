#include <stdio.h>
#include <stdlib.h>

int a = 1;

void f(int c) {
  int a = c, b = 6;
  a++;
  printf("f(): \ta = %d \tb = %d \tc = %d\n", a, b, c);
  {
    int a = 7;
    b++;
    printf("bloc f(): \ta = %d \tb = %d \tc = %d\n", a, b, c);
  }
  printf("fin f(): \ta = %d \tb = %d \tc = %d\n", a, b, c);
}

int main(int argc, char *argv[]) {
  int c = 4;
  printf("main(): \ta = %d \tc = %d\n", a, c);
  f(c);
  printf("main(): \ta = %d \tc = %d\n", a, c);
  return EXIT_SUCCESS;
}
