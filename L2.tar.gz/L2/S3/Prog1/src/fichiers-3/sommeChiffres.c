#include <stdio.h>
#include <stdlib.h>

int main(void) {

  int nbrchoix, unite, decimal;
  do{
    printf("choisit un nombre : ");
    scanf("%d", &nbrchoix);
    if(nbrchoix<10 || nbrchoix>99) {
      printf("ce n est pas un nombre compatible\n");
    }
  }while(nbrchoix<10 || nbrchoix>99);
 
 

    unite = nbrchoix%10;
    decimal = nbrchoix/10;
    printf("Le resultat est : %d\n", unite+decimal);


  
  return EXIT_SUCCESS;
}
