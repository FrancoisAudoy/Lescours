public class TableauEntiers{
    public static void afficher(int[] t){
	for(int i=0; i<t.length; i++)
	    System.out.print(" " + t[i]);
	System.out.println();
    }

    public static void main(String[] args){
	int[] t = new int [20];
	for(int i=0; i<t.length; i++)
	    t[i]= 2*i;
	t[14] = 50;
	t[10] = -2;

	afficher(t);
	
	// System.out.println("La somme des elements est " + somme(t));
	// System.out.println("Le min des elements est " + minimum(t));
	// System.out.println("L'indice du max des elements est " + indiceMaxi(t));
	// System.out.println(" Le tableau des opposes est: ");
	// afficher(opposes(t));
    }

}
