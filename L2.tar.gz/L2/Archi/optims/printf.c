#include <stdio.h>
void f(int x) {
	switch(x) {
		case 1: printf("foo\n"); break;
		case 2: printf("bar\n"); break;
		case 3: printf("baz\n"); break;
	}
}
