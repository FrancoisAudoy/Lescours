unsigned g(unsigned x){
  return x/3;
}
