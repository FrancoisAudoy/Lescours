int mon_strlen(char *p) {
	char *c;
	for (c = p; *c; c++)
		;
	return c-p;
}
