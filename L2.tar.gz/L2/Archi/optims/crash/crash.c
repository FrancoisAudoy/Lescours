#include <stdio.h>

void f(int i) {
	char s[8];
	int n;
	n = sprintf(s, "%d--%d\n", i, i+1);
	write(2,s,n);
}

int x = 1000000000;

int main(void) {
	int i = x;
	f(i);
	return i;
}
