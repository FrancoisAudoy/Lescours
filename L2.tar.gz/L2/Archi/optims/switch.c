int f(int x) {
	switch(x) {
		case 0: return 'A';
		case 1: return 'Z';
		case 2: return 'E';
		case 3: return 'R';
		case 4: return 'T';
		case 5: return 'Y';
	}
}
