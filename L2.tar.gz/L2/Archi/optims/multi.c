unsigned f(unsigned x){
  return 7*x;
}
