int f(int x){
  return 2*x;
}

int g(int x, int y){
  return 2*x+y;
}

int h(int x, int y){
  return 2*x+3*y;
}

int j(int x, int y){
  return f(x)+g(x,y)+h(x,y);
}
