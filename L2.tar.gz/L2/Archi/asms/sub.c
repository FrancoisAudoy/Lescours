extern int g(int x);
int sub(int x, int y){
return g(x)-g(y);
}
