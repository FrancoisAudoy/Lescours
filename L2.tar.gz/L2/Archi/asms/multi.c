int g(int x){
  return 3*x;
}
