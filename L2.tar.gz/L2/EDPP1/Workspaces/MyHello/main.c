/*
 * main.c
 *
 *  Created on: 30 mars 2016
 *      Author: faudoy
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	printf("coucou");
}
