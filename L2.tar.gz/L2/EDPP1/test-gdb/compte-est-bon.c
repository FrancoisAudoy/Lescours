#include <stdlib.h>
#include <stdio.h>


void copier(char *source, char *destination)
{
  int i;
  for(i = 0; source[i] != 0; i++)
    destination[i] = source[i];
  destination[i]=0;
}

char chaine1[255];
char chaine2[] = "en utilisant watch nom_variable. L'arrêt peut être conditionnel en utilisant watch condition.";
char chaine3[] = " lorsque le contenu de la variable change de valeur";
char chaine4[] = "Il est possible de créér des points d'arrêt";

int dix = 10;

int main()
{

 copier(chaine2,chaine1);
 copier(chaine4,chaine2);
 copier(chaine1,chaine4);
 copier(chaine3,chaine1);
 
 printf("%s%s%s\n", chaine2, chaine3, chaine4);

  printf("20/10=%d\n",20/dix);
  return 0;
}

