#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

typedef struct pile *pile;

pile pil_creer(void);
void pil_liberer(pile * p);
int pil_pile_vide(pile p);
void pil_empiler(int i, pile * p);
int pil_depiler(pile * p);
int pil_valeur_sommet(pile p);


struct pile
  {
    int element;
    pile suivant;
  };


pile
pil_creer(void)
{
  return (pile) NULL;
}

void
pil_liberer(pile * p)
{
  pile p1, suiv;
  assert(p != NULL);

  p1 = *p;
  while (p1 != NULL)
    {
      suiv = p1->suivant;
      free(p1);
      p1 = suiv;
    }
  *p = NULL;
}

int
pil_pile_vide(pile p)
{
  return p == NULL;
}

void
pil_empiler(int i, pile * p)
{
  pile top = malloc(sizeof(struct pile));
  assert(p != NULL && top != NULL);
  top->element = i;
  top->suivant = *p;
  *p = top;
}

int
pil_depiler(pile * p)
{
  struct pile sommet;
  assert(p != NULL && *p != NULL);
  sommet = **p;
  pile *p1=p;
  (*p1)->suivant=NULL;
  pil_liberer(p1);
  *p = sommet.suivant;
  return sommet.element;
}

int
pil_valeur_sommet(pile p)
{
  assert(p != NULL);
  return p->element;
}


#define MAX 5

int
main()
{
  pile p ;
  long i ;
  p = pil_creer();
  
  for (i = 0 ; i < MAX; i++){
    pil_empiler(i,&p);
  }

  while (! pil_pile_vide(p))
    {
      printf("depile %d\n", pil_depiler(&p));
    }

  return EXIT_SUCCESS;  
}
