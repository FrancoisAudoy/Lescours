#include <stdlib.h>
#include <stdio.h>
#include <string.h>




char * copier(char *source, char *destination)
{
  int i;
  for(i = 0; source[i] != 0; i++)
    destination[i] = source[i];
  destination[i]='\0';

  return destination;
}


char *chaine_dupliquer(char *s)
{
  return copier(s,malloc(strlen(s)+1));
}

int main()
{

 
char chaine1[255];
 char *chaine2 = chaine_dupliquer("en utilisant watch nom_variable. L'arrêt peut être conditionnel en utilisant watch condition.");
 char *chaine3 = chaine_dupliquer(" lorsque le contenu de la variable change de valeur");
char *chaine4 = chaine_dupliquer("Il est possible de créér des points d'arrêt");

int dix = 10;

 copier(chaine2,chaine1);
 copier(chaine4,chaine2);
 copier(chaine1,chaine4);
 copier(chaine3,chaine1);
 
 printf("%s%s%s\n", chaine2, chaine3, chaine4);

 free(chaine2);
 free(chaine3);
 free(chaine4);

  return 0;
}

