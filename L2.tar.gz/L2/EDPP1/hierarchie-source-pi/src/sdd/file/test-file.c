#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "memoire.h"
#include "chaine.h"

#include "file.h"

#define TAILLE_TEMPON_ENTREE 1024

static void
L_afficher(void *p)
{
    char *s = p;

    printf("<%s> ", s);
}

int
main(int argc, char *argv[])
{
    file f;

    if (argc == 2 && strcmp(argv[1], "--trace") == 0)
	memoire_trace(1);
    f = file_creer();

    for (;;)
    {
	char tampon[TAILLE_TEMPON_ENTREE];

	if (fgets(tampon, sizeof(tampon), stdin) == NULL || tampon[0] == 'Q')
	    break;

	switch (tampon[0])
	{
	  case 'E':
	  {
	      /* Suppression du caract�re \n final */
	      tampon[strlen(tampon)-1] = '\0';

	      file_enfiler(f, chaine_dupliquer(tampon+2));
	      break;
	  }

	  case 'D':
	  {
	      char *s = file_tete(f);

	      file_defiler(f);
	      printf("T�te : %s\n", s);
	      memoire_liberer(s);
	      break;
	  }

	  case 'V':
	    printf("File vide : %s\n", file_vide(f) ? "vrai" : "faux");
	    break;

	  case 'P':
	    file_iterer(f, L_afficher);
	    printf("\n");
	    break;

	  default:
	    break;
	}
    }
    file_liberer(f, memoire_liberer);
    return EXIT_SUCCESS;
}
