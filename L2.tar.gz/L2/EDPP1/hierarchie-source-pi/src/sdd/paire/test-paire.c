#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "paire.h"

static char chaine[7] = "";


static void
traitement(void *p)
{
    strcat(chaine, (char *) p);
}

int 
main(int argc, char *argv[])
{
    char *chaine_a = "a";
    paire p1 = paire_creer(chaine_a, NULL);
    paire p2 = paire_creer(NULL, NULL);
    paire p3;

    assert(paire_car(p1) == chaine_a);
    assert(paire_cdr(p1) == NULL);

    paire_modifier_car(p2, "bb");
    paire_modifier_cdr(p1, p2);

    p3 = paire_creer("ccc", p1);

    paire_iterer(p3, traitement);
    assert(strcmp(chaine, "cccabb") == 0);

    printf("Test du module paire r�ussi\n");
    return EXIT_SUCCESS;
}
