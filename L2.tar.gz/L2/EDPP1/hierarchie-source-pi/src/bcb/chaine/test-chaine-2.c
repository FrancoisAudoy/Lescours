
#include <stdio.h>
#include <stdlib.h>

#include "chaine.h"
#include "memoire.h"

#define CARACTERE_SEPARATION '.'

void
usage(const char *nom_du_programme) {

    fprintf(stderr, "usage: %s chaine1 chaine2\n", nom_du_programme);
    exit(EXIT_FAILURE);
}

int
main(int argc, char *argv[]) {
    char *chaine1;
    char *chaine2;
    char *concat;
    char *temp;

    if (argc != 3) {
	usage(argv[0]);
    }

    chaine1 = chaine_dupliquer(argv[1]);
    chaine2 = chaine_dupliquer(argv[2]);

    printf("chaine 1 : \"%s\"\n", chaine1);
    printf("chaine 2 : \"%s\"\n", chaine2);

    concat = chaine_concatener(chaine1, chaine2);
    printf("chaines concat�n�es : \"%s\"\n", concat);    

    temp = chaine_vers_majuscules(chaine1);
    printf("Premi�re chaine en majuscules : \"%s\"\n", temp);
    memoire_liberer(temp);

    temp = chaine_vers_minuscules(chaine2);
    printf("Deuxi�me chaine en minuscules : \"%s\"\n", temp);
    memoire_liberer(temp);

    temp = chaine_prefixe(chaine1, CARACTERE_SEPARATION);
    printf("prefixe de \"%s\" avant le dernier caract�re '%c' :\n \"%s\"\n",
	chaine1, CARACTERE_SEPARATION, temp);
    memoire_liberer(temp);

    temp = chaine_suffixe(chaine1, CARACTERE_SEPARATION);
    printf("suffixe de \"%s\" apr�s le dernier caract�re '%c' :\n \"%s\"\n",
	chaine1, CARACTERE_SEPARATION, temp);
    memoire_liberer(temp);

    printf("\nV�rifiez que les r�sultats sont coh�rents\n");

    return EXIT_SUCCESS;
}
