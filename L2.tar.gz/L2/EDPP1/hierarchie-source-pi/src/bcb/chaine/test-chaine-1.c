
#include <stdio.h>
#include <stdlib.h>

#include "chaine.h"

#define CARACTERE_A_REMPLACER 'i'
#define CARACTERE_DE_REMPLACEMENT 'o'

#define CHAINE_DE_TEST "Kilimandjaro"

int
main(void) {
    char chaine[] = CHAINE_DE_TEST;
    int nb1 = chaine_compter_occurrences(chaine, CARACTERE_A_REMPLACER);
    int nb2 = chaine_compter_occurrences(chaine, CARACTERE_DE_REMPLACEMENT);
    
    printf("chaine initiale : \"%s\"\n", chaine);
    printf("occurrences de %c : %d\n", CARACTERE_A_REMPLACER, nb1);
    printf("occurrences de %c : %d\n", CARACTERE_DE_REMPLACEMENT, nb2);

    chaine_remplacer_occurrences(chaine, CARACTERE_A_REMPLACER,
	CARACTERE_DE_REMPLACEMENT);

    printf("chaine apr�s remplacement de %c par %c :\n \"%s\"\n",
	CARACTERE_A_REMPLACER, CARACTERE_DE_REMPLACEMENT, chaine);

    if (chaine_compter_occurrences(chaine, CARACTERE_A_REMPLACER) != 0) {
	fprintf(stderr, "certains caract�res n'ont pas �t� remplac�s\n");
	return EXIT_FAILURE;
    }

    if (nb1 + nb2 !=
		chaine_compter_occurrences(chaine, CARACTERE_DE_REMPLACEMENT)) {
	fprintf(stderr, "Le test de coh�rence a �chou�\n");
	return EXIT_FAILURE;
    }

    fprintf(stderr, "Test pass� avec succ�s\n");
    return EXIT_SUCCESS;
}
