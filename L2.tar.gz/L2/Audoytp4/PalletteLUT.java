import ij.ImagePlus;
import ij.plugin.filter.*;
import ij.process.*;

public class PalletteLUT implements PlugInFilter{
	byte r[]= new byte[256];
	byte v[]= new byte[256];
	byte b[]= new byte[256];

	
	public void run (ImageProcessor ip){
		LUT lut=ip.getLut();
		
		for(int y=0; y<ip.getWidth(); ++y)
			for(int x=0; x<ip.getHeight(); ++x)
				
		
		}
			
		
		
		
	

	public int setup(String arg, ImagePlus imp) {
		// TODO Auto-generated method stub
		return DOES_RGB;
  }
}
