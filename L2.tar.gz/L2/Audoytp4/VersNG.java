import ij.*;
import ij.gui.*;

import java.awt.*;

import ij.plugin.filter.PlugInFilter;
import ij.process.*;

public class VersNG implements PlugInFilter {
	
	public int couleurVersNG(int couleur) {
		int rouge = (couleur& 0xff0000) >>16;
		int vert= (couleur& 0x00ff00)>> 8;
		int bleu= couleur & 0x0000ff;
		int niveauGris= (int)(0.3*rouge+0.59*vert+0.11*bleu);
		return ((niveauGris<<16) +(niveauGris<<8)+niveauGris);

	}

	
	public void run (ImageProcessor ip){
		
		for(int i=0; i<ip.getWidth();++i){
			for(int y=0; y<ip.getHeight();++y){
					ip.putPixel(i, y, couleurVersNG(ip.getPixel(i, y)));
			}
	
		}
	}
	
	public int setup(String arg, ImagePlus imp) {
	    // TODO Auto-generated method stub
	    return DOES_RGB;
	  }
}
